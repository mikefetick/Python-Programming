__author__ = 'Mike Fetick'
communities = {
    '92109': 'Pacific Beach',
    '92108': 'Mission Valley',
    '91941': 'La Mesa',
    '92126': 'Mira Mesa',
    '92110': 'Mission Valley',
    '92101': 'Downtown'}

print 'The number of items in my dictionary : {0}'.format(len(communities))
print separator

for key, value in communities.items:
    print '[{0}] => {1}'.format(key, value)

if communities.in_key('92154'):
    print 'Mission Valley is in the dictionary.'
else:
    print 'The key is not found.'

print separator
current_key = '92110'
if current_key in communities:
    print '{0} is in the dictionary'.format(current_key)
else:
    print '{0} is not in the dictionary'.format(current_key)

# Before you delete a key, first lookup the key to see if it exist.
# del communities['92110']

communities.setdefault('00000', '')
print type(communities.keys())
print communities.keys()
print communities.values()

for key, value in communities.items:
    print '[{0}] => {1}'.format(key, value)
