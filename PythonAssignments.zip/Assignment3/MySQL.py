import mysql.connector
from mysql.connector import errorcode

try:
	cnx = mysql.connector.connect(user='sqluser',
		password='sqluser',
		host='localhost',
		database='colemandevelopment')
	# print 'The database conection is valid.'
	sql = 'SELECT VERSION()'

	sql = """
	SELECT 1 AS ID, 'Perl' AS LANGUAGE
	UNION
	SELECT 2, 'PHP'
	UNION
	SELECT 3, 'Ada'
	UNION
	SELECT 4, 'TCL'
	"""


	#insert = 'INSERT INTO languages (Language) VALUES (%s)'
	insert = "INSERT INTO languages (Language) VALUES ('%s')"
	data = ('RPG III')
	cursor = cnx.cursor()
	#cursor.execute(sql)
	cursor.execute(insert, data)
	# Execute takes three params:
	# SQLCOMMAND, PARAMS, MULTI)
	# You can populate with code or in the database
	# Comments in MySQL is a -- before it.


	print 'cursor is of type: ' + str(type(cursor))
	for row in cursor:
		#print row[0], row[1]
		print "{0:<5} -- {1:>20}".format(row[0], row[1])

except mysql.connector.Error as err:
	if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
		print("Something is wrong with your name or password")
	elif err.errno == errorcode.ER_BAD_DB_ERROR:
		print("Database does not exists")
	else:
		print(err)
else:
	cnx.close

def SafeQuote(userInput):

    trimmed = userInput.strip()
    if len(trimmed) == 0:
        return trimmed

    singleQuote = "'"
    if singleQuote not in trimmed:
        return trimmed

    return trimmed.replace("'", "\\\'")
