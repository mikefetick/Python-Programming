#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows
__author__ = 'Michael Fetick'
# 2/19/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 3 - Classes and Database
import abc 		# Import the abstract class module
import datetime
import dateutil
from dateutil.parser import *


class DatabaseProcessor:
	"""
	2.  Create an abstract class with two abstract methods:
	    a.  One method to select data from a database (selectStudent)
	    b.  One method to insert data into a database (insertStudent)
	"""
	"""
	3.  Decorate the abstract methods with attributes to 
		indicate that the methods are abstract methods.
	"""
	@abc.abstractmethod
	def insertStudent (self, 
		student_id, first_name, last_name, major, enrollment_date, graduation_date):
		# Convert from system date to mySQL date format
		mySQL_ed = dateutil.parser.parse(enrollment_date)
		mySQL_gd = dateutil.parser.parse(graduation_date)
		sql = ("INSERT INTO `ad84270`.`students` "
			"(`StudentID`,`FirstName`,`LastName`,`Major`,`EnrollmentDate`,`GraduationDate`)"
			" VALUES "
			"('" + student_id + "',"
			 "'" + first_name + "',"
			 "'" + last_name + "',"
			 "'" + major + "',"
			 "'" + str(mySQL_ed) + "',"
			 "'" + str(mySQL_gd) + "');")
		return sql

	@abc.abstractmethod
	def selectStudent(self, page, offset):
		sql = (
			"SELECT (`StudentID`,`FirstName`,`LastName`,`Major`,`EnrollmentDate`,`GraduationDate`)"
			" FROM `ad84270`.`students LIMIT page , offset;")
		return sql

	@abc.abstractmethod
	def getFullName(self):
		return '{0} {1}'.format(self.FirstName.title, self.LastName.title)
		#return first[0].upper() + first[1:].lower()
		#FN = [x.title() for x in self.name]
		#return join (FN, '')
