#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows
__author__ = 'Michael Fetick'
# 2/19/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 3 - Classes and Database
# http://stackoverflow.com/questions/15252040
# /how-does-python-find-a-module-file-if-the-import-statement-only-contains-the-fil

import abc 		# Import the abstract class module
import datetime
# http://stackoverflow.com/questions/127803/how-to-parse-iso-formatted-date-in-python
import dateutil

separator = "    " + '-' * 59

#now = datetime.now()
dateToday = datetime.date.today()
#timeNow = dateutil.
class student:
	"""
	1.  Create a Student Class that contains the following 
	    properties:
	    a.  StudentId
	    b.  FirstName
	    c.  LastName
	    d.  Major
	    e.  EnrollmentDate
	    f.  GraduationDate
	"""
	def __init__(self, 
		student_id, first_name, last_name, major, enrollment_date, graduation_date):
		self.StudentId = student_id
		self.FirstName = first_name
		self.LastName = last_name
		self.Major = major
		self.EnrollmentDate = enrollment_date
		self.GraduationDate = graduation_date

	def getFullName(self):
		return '{0} {1} {2} {3} {4} {5}'.format(
			self.StudentId, 
			self.FirstName, 
			self.LastName, 
			self.Major, 
			self.EnrollmentDate, 
			self.GraduationDate)

	def modifyTheVariable(self):
		self.StudentId = 100
		print self.StudentId

	def getDateDifference(self,
		earlierDate, laterDate):
		# Validate date format. Ref: http://www.regexlib.com/REDetails.aspx?regexp_id=60 (Limits to after 1989)
		# regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/(([1]{1}[9]{1}[9]{1}\d{1})|([2-9]{1}\d{3}))$") 
		regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/\d{4}$") 
		if regexp.match(earlierDate):
			if regexp.match(laterDate):
				dateStr1 = earlierDate
				dateStr2 = earlierDate
				m1, d1, y1 = (int(x) for x in dateStr1.split('/'))
				m2, d2, y2 = (int(x) for x in dateStr2.split('/'))
				try:
					date1 = dt.date(y1, m1, d1)
					date2 = dt.date(y2, m2, d2)
					if (date1 > date2):
						dateDiff = date1 - date2
						#dateDiffStr = str(dateDiff).strip(', 0:00:00')	# Strip the time - (unused, I want commas)
						dayStr = (' days' if dateDiff.days > 1 else ' day')		# ternary assignment
						dateDiffStr = '{:,}'.format(dateDiff.days) + dayStr		# format for a comma separator
						return dateDiffStr
				except Exception: 
					pass

	def formatListOfStudents(self):
		daysSince = 0
		sinceDate = dateutil.parser.parse("11-05-2014")

		print dateToday
		if (dateToday > self.GraduationDate):
			#sinceDate = parse(self.GraduationDate)

			#sinceDate = dateutil.parser.parse("12-05-2014")
			#daysSince = sinceDate - dateToday
			daysSince = getDateDifference(dateToday, self.GraduationDate)
			
		elif (dateToday > self.EnrollmentDate):
			#sinceDate = parse(self.EnrollmentDate)

			#sinceDate = dateutil.parser.parse("11-05-2014")
			#daysSince = sinceDate - dateToday
			daysSince = getDateDifference(dateToday, self.EnrollmentDate)

		return '{0:5} {1:25} {2:15} {3:10} {4:10} {5:4} {6}'.format(
			self.StudentId, 
			self.FirstName, 
			self.LastName, 
			self.Major, 
			self.EnrollmentDate, 
			self.GraduationDate,
			daysSince)
		

s = student('s0001', 'John', 'Smith', 'SD', '02/01/2015', '01/30/2018')
print s.getFullName()
print s.modifyTheVariable()
print s.getFullName()

print s.formatListOfStudents()


class DatabaseProcessor:
	"""
	2.  Create an abstract class with two abstract methods:
	    a.  One method to select data from a database (SelectDataFromDB)
	    b.  One method to insert data into a database (InsertDataIntoDB)
	"""
	"""
	3.  Decorate the abstract methods with attributes to 
		indicate that the methods are abstract methods.
	"""

	@abc.abstractmethod

	def __init__(self, 
		student_id, first_name, last_name, major, enrollment_date, graduation_date):
		self.StudentId = student_id
		self.FirstName = first_name
		self.LastName = last_name
		self.Major = major
		self.EnrollmentDate = enrollment_date
		self.GraduationDate = graduation_date


	def SelectDataFromDB(self):
		print "This method will select data from a database."

	def InsertDataIntoDB(self):
		print "This method will insert data into a database."


def printPageFooter(n):
	# Print the footer row
	timeNow = ""
	print '    Page 1 of {0}        Executed At:  {1}'.format(n, timeNow)


def printPageHeader():
	# Print the header row
	print '  ID   FullName    Major Enrollment  Graduation  Days Since'


def displayListOfStudents(listOfStudents):
	"""
	5.  Display the list of Students in this format:

	      ID   FullName    Major	Enrollment  Graduation  Days Since
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX

	    Page 1 of N        Executed At:  03-01-2015 19:35

	    * Where N is the total number of pages.
	    * If the StudentId is less that five digits, left 
	      pad the value with '0'
	    * The column widths are specified as:
	      5, 25, 15, 10, 10, 4
	"""
	printPageHeader()
	# Connect to the database

	# Iterate through the database query of students
	i, n = 1
	for s in SelectDataFromDB():
		if i > 25:    # number of lines per page = 25
			i = 1
			printPageFooter(n)
			printPageHeader()
			n += 1
		print s.formatListOfStudents()
		i += 1
	printPageFooter()


class SubClassDatabaseProcessor(DatabaseProcessor):
	"""
	4.  Create a class that implements the abstract class.
	    When retrieving the data from the database, the 
	    method should populate a list of Students
	"""
	def __init__(self):
		pass

	def DoSomething(self):
		print "I am doing something."

sc = SubClassDatabaseProcessor()
sc.DoSomething()
sc.SelectDataFromDB()
sc.InsertDataIntoDB()


def computePaging():
	"""
	6.  The parameters are offsets to allow paging from 
	    the database/list.  The first parameter is the 
	    page number and the second parameter is the 
	    number of records to display.  Example:

	    Assignment3.py 5, 10   # Display records 41-50
	    Assignment3.py 3, 17   # Display records 35-51
	    Assignment3.py 6, 22   # Display records 111-132
	"""
	pass


def deliverables():
	print """
	Hello
	"""


def specification():
	print "            specification()"	
	print """
	Due 03-10-2015 11:55 p.m.

	You are tasked with creating a Python script that 
	takes two parameters:

	1.  Create a Student Class that contains the following 
	    properties:
	    a.  StudentId
	    b.  FirstName
	    c.  LastName
	    d.  Major
	    e.  EnrollmentDate
	    f.  GraduationDate

	2.  Create an abstract class with two abstract methods:
	    a.  One method to select data from a database
	    b.  One method to insert data into a database

	3.  Decorate the abstract methods with attributes to 
		indicate that the methods are abstract methods.

	4.  Create a class that implements the abstract class.
	    When retrieving the data from the database, the 
	    method should populate a list of Students
	    
	5.  Display the list of Students in this format:

	      ID   FullName    Major	Enrollment  Graduation  Days Since
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX

	    Page 1 of N        Executed At:  03-01-2015 19:35

	    * Where N is the total number of pages.
	    * If the StudentId is less that five digits, left 
	      pad the value with '0'
	    * The column widths are specified as:
	      5, 25, 15, 10, 10, 4

	6.  The parameters are offsets to allow paging from 
	    the database/list.  The first parameter is the 
	    page number and the second parameter is the 
	    number of records to display.  Example:

	    Assignment3.py 5, 10   # Display records 41-50
	    Assignment3.py 3, 17   # Display records 35-51
	    Assignment3.py 6, 22   # Display records 111-132

	..."""


def main():
	if __name__ == "__main__":
		deliverables()

try:
	# Debugging with outer try statement replaces Phython's Top-Level Exception Handling
	main()
except EOFError, e:	
	# raw_input() raises a built-in EOFError Exception Signal (not an error)
	assert e
except:
	# Display all exceptions without program termination
	print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])
	# Display the call stack
	traceback.print_exc()										
	raw_input("        Press the Enter key to exit")

