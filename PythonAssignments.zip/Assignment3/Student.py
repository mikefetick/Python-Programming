#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows
__author__ = 'Michael Fetick'
# 2/19/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 3 - Classes and Database


class student:
	"""
	A class is a data type.
	They may have methods, properties.
	1. Break the object down to attributes and methods
	   In .NET, methods are called properties, with fields.
	   In Java, methods expose fields.

	1.  Create a Student Class that contains the following 
	    properties:
	    a.  StudentId
	    b.  FirstName
	    c.  LastName
	    d.  Major
	    e.  EnrollmentDate
	    f.  GraduationDate
	"""
	def __init__(self, 
		student_id, first_name, last_name, major, enrollment_date, graduation_date):
		self.StudentId = student_id
		self.FirstName = first_name
		self.LastName = last_name
		self.FullName = first_name + ' ' + last_name
		self.Major = major
		self.EnrollmentDate = enrollment_date
		self.GraduationDate = graduation_date

	# Convert objects to strings
	def __repr__(self):
		return repr((
			self.StudentId,
			self.FirstName,
			self.LastName,
			self.FullName,
			self.Major,
			self.EnrollmentDate,
			self.GraduationDate
			))
