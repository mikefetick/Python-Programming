#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows
__author__ = 'Michael Fetick'
# 2/19/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 3 - Classes and Database


import traceback   # Debugging errors during runtime
import datetime
import dateutil
from dateutil.parser import *
from dateutil.relativedelta import *
import sys
from sys import argv

import Student
import DatabaseDriver
from DatabaseDriver import *


def usage():
	print ''
	print ' Usage:                [args]:'
	print ' - INTERACTIVE MODE -  []'
	print ' - USAGE and HELP   -  [ help | ? ]  ( displays this screen )'
	print ' - CMD-LINE REPORT  -  [ 2, 15 ]     ( page number, records per page )'
	print ' - CMD-LINE INSERT  -  [ enter new student information (no commas) ]'
	print '                         1)StudentId  2)FirstName       3)LastName'
	print '                         4)Major      5)EnrollmentDate  6)GraduationDate'
	print "              example: s0069 Suzy Cue English 02/01/2015 01/30/2018"


def interactiveMode():
	print ''
	print ' - INTERACTIVE MODE -  (See the example above)'
	print '   Entry:',
	studentInfo = raw_input()
	tokens = studentInfo.split(' ')
	if (len(tokens) != 6):
		print '   Error - You entered', len(tokens), \
		'field(s), you must enter all the data (6 fields)'
	else:
		myStudent = Student.student(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5])
		if (myStudent):
			db = DatabaseProcessor()
			try:
				mySQL_ed = str(dateutil.parser.parse(repr(tokens[4])))
				mySQL_gd = str(dateutil.parser.parse(repr(tokens[5])))
			except ValueError, e:
				print '"%s" is an invalid date' % ds
				sys.exit(0)  # 0 (the default) means success, non-zero means failure
			sql = db.insertStudent(tokens[0], tokens[1], tokens[2], tokens[3], mySQL_ed, mySQL_gd)
			connectMySQL(sql)
			#db.SelectStudent(0, 30)
		#displayListOfStudents(listOfStudents)
		return sql

def cmdlineReport():
	db.SelectStudent(0, 30)


def cmdlineInsert():
	print str(sys.argv)
	if (len(sys.argv) != 7):
		print '   Error - You entered', len(sys.argv), \
		'field(s), you must enter all the data (6 fields)'
	else:
		myStudent = Student.student(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6])
		if (myStudent):
			db = DatabaseProcessor()
			try:
				mySQL_ed = str(dateutil.parser.parse(repr(argv[5])))
				mySQL_gd = str(dateutil.parser.parse(repr(argv[6])))
			except ValueError, e:
				print '"%s" is an invalid date' % ds
				sys.exit(0)  # 0 (the default) means success, non-zero means failure
			sql = db.insertStudent(argv[1], argv[2], argv[3], argv[4], mySQL_ed, mySQL_gd)
			connectMySQL(sql)
			#db.SelectStudent(0, 30)
		#displayListOfStudents(listOfStudents)
		return sql


def getDateDifference(self, earlierDate, laterDate):
	# Validate date format. Ref: http://www.regexlib.com/REDetails.aspx?regexp_id=60 (Limits to after 1989)
	# regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/(([1]{1}[9]{1}[9]{1}\d{1})|([2-9]{1}\d{3}))$") 
	regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/\d{4}$") 
	if regexp.match(earlierDate):
		if regexp.match(laterDate):
			dateStr1 = earlierDate
			dateStr2 = earlierDate
			m1, d1, y1 = (int(x) for x in dateStr1.split('/'))
			m2, d2, y2 = (int(x) for x in dateStr2.split('/'))
			try:
				date1 = dt.date(y1, m1, d1)
				date2 = dt.date(y2, m2, d2)
				if (date1 > date2):
					dateDiff = date1 - date2
					#dateDiffStr = str(dateDiff).strip(', 0:00:00')	# Strip the time - (unused, I want commas)
					dayStr = (' days' if dateDiff.days > 1 else ' day')		# ternary assignment
					dateDiffStr = '{:,}'.format(dateDiff.days) + dayStr		# format for a comma separator
					return dateDiffStr
			except Exception: 
				pass


def formatListOfStudents(self):
	# This method will extract data from the database.
	self.StudentId = student_id
	self.FirstName = first_name
	self.LastName = last_name
	self.FullName = first_name + ' ' + last_name
	self.Major = major
	self.EnrollmentDate = enrollment_date
	self.GraduationDate = graduation_date

	daysSince = 0
	sinceDate = dateutil.parser.parse("11-05-2014")

	print dateToday
	print self.GraduationDate
	if (dateToday > self.GraduationDate):
		#sinceDate = parse(self.GraduationDate)

		#sinceDate = dateutil.parser.parse("12-05-2014")
		#daysSince = sinceDate - dateToday
		daysSince = getDateDifference(dateToday, self.GraduationDate)
		
	elif (dateToday > self.EnrollmentDate):
		#sinceDate = parse(self.EnrollmentDate)

		#sinceDate = dateutil.parser.parse("11-05-2014")
		#daysSince = sinceDate - dateToday
		daysSince = getDateDifference(dateToday, self.EnrollmentDate)

	# Convert back to system date from mySQL date format
	enrollment_date = parse(datetime.datetime.strftime(mySQL_ed, '%m/%d/%Y'))
	graduation_date = parse(datetime.datetime.strftime(mySQL_gd, '%m/%d/%Y'))

	return '{0:5} {1:25} {2:15} {3:10} {4:10} {5:4} {6}'.format(
		self.StudentId, 
		self.FirstName, 
		self.LastName, 
		self.Major, 
		self.EnrollmentDate, 
		self.GraduationDate,
		daysSince)


def safeQuote(input):
    trimmed = input.strip()
    if len(trimmed) == 0:
        return input
    singleQuote = "'"
    if singleQuote not in trimmed:
        return input
    return trimmed.replace("'", "\\\'")


def printPageHeader():
	# Print the header row
	print '  ID   FullName    Major Enrollment  Graduation  Days Since'


def displayListOfStudents(listOfStudents):
	#Print sys.argv[0]     # script name
	#Print sys.argv[1]     # page number
	#Print sys.argv[2]     # number of records
	#Print sys.argv[3]     # any date
	print """
	5.  Display the list of Students in this format:

	      ID   FullName    Major	Enrollment  Graduation  Days Since
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX

	    Page 1 of N        Executed At:  03-01-2015 19:35

	    * Where N is the total number of pages.
	    * If the StudentId is less that five digits, left 
	      pad the value with '0'
	    * The column widths are specified as:
	      5, 25, 15, 10, 10, 4
	"""
	printPageHeader()
	# Connect to the database

	# Iterate through the database query of students
	i, n = 1
	for s in SelectDataFromDB():
		if i > 25:    # number of lines per page = 25
			i = 1
			printPageFooter(n)
			printPageHeader()
			n += 1
		print s.formatListOfStudents()
		i += 1
	printPageFooter()


def computePaging():
	"""
	6.  The parameters are offsets to allow paging from 
	    the database/list.  The first parameter is the 
	    page number and the second parameter is the 
	    number of records to display.  Example:

	    Assignment3.py 5, 10   # Display records 41-50
	    Assignment3.py 3, 17   # Display records 35-51
	    Assignment3.py 6, 22   # Display records 111-132
	"""
	n = 10   # Dummy number for test
	printPageFooter(n)


def printPageFooter(n):
	# Print the footer row
	#For pagination try the limit keyword in the SQL statement.
	pageNo = sys.argv[1]
	if (pageNo > n):
		pageNo = n
	print '    Page {0} of {1}        Executed At:  {2}'.format(pageNo, n, dateNow)


def specification():
	"""
	Due 03-10-2015 11:55 p.m.

	You are tasked with creating a Python script that 
	takes two parameters:

	1.  Create a Student Class that contains the following 
	    properties:
	    a.  StudentId
	    b.  FirstName
	    c.  LastName
	    d.  Major
	    e.  EnrollmentDate
	    f.  GraduationDate

	2.  Create an abstract class with two abstract methods:
	    a.  One method to select data from a database
	    b.  One method to insert data into a database

	3.  Decorate the abstract methods with attributes to 
		indicate that the methods are abstract methods.

	4.  Create a class that implements the abstract class.
	    When retrieving the data from the database, the 
	    method should populate a list of Students
	    
	5.  Display the list of Students in this format:

	      ID   FullName    Major	Enrollment  Graduation  Days Since
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX
	    XXXXX XXXX XXXX    XXXXX	MM/DD/YYYY  MM/DD/YYYY     XXXX

	    Page 1 of N        Executed At:  03-01-2015 19:35

	    * Where N is the total number of pages.
	    * If the StudentId is less that five digits, left 
	      pad the value with '0'
	    * The column widths are specified as:
	      5, 25, 15, 10, 10, 4

	6.  The parameters are offsets to allow paging from 
	    the database/list.  The first parameter is the 
	    page number and the second parameter is the 
	    number of records to display.  Example:

	    Assignment3.py 5, 10   # Display records 41-50
	    Assignment3.py 3, 17   # Display records 35-51
	    Assignment3.py 6, 22   # Display records 111-132

	..."""


def main():
	"""
	The third and final assignment involves classes.
	We need to test for __main__.

	Creating a class in Python is no more difficult than any other language,
	E.G. Create a class:
	Indicate what the class does. 
	Create constructor (mimiced with the init attribute)
	Pass in two values: lastname and firstname
	Now we have initialized the values.
	Python doesn't explicity have properties but we can mimic it
	with get().
	Use Title case.
	Irish names like O'B... use regex. 
	To do regex, use a case to develop the regex string:
	O'Brian - "^O'[A-Z][a-z]+$"
	MacDonald - "^Mac[a-z]+$"
	Oscar De La Hoya - ""

	instance type - don't need to use the 'new' keyword
	object type 

	at a dos prompt> appwiz.cpl (brings up the control panel)

	instance class
	static class
	abstract class (must import the abstract module - import abc)
	@abc.abstractmethod  # Note the '@' symbol

	Next week: database, commandline processing, custom exception handler
	"""
	usage()
	argCount = len(sys.argv)
	if argCount == 1:
		interactiveMode()
	elif argCount == 3:
		print ' - COMMAND-LINE REPORT -'
		cmdlineReport()
	elif argCount == 7:
		print ' - COMMAND-LINE INSERT -'
		cmdlineInsert()
	else:
		pass

	#Raise the exception by using a try block.
	try:
		# Debugging with outer try statement replaces Phython's Top-Level Exception Handling
		pass

	except EOFError, e:	
		# raw_input() raises a built-in EOFError Exception Signal (not an error)
		assert e
	except:
		# Display all exceptions without program termination
		print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])
		# Display the call stack
		traceback.print_exc()										
		raw_input("        Press the Enter key to exit")


try:
	if __name__ == "__main__":
		# Debugging with outer try statement replaces Phython's Top-Level Exception Handling
		main()
except EOFError, e:	
	# raw_input() raises a built-in EOFError Exception Signal (not an error)
	assert e
except:
	# Display all exceptions without program termination
	print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])
	# Display the call stack
	traceback.print_exc()										
	raw_input("        Press the Enter key to exit")


# SomeException IOError (subtype | subclass of Exception)
class ErrorWithArgs(Exception):
    def __init__(self, *args):
        # *args is used to get a list of the parameters passed in
        self.args = [a for a in args]
try:
    raise ErrorWithArgs(1, "text", "some more text")
except ErrorWithArgs as e:
	pass
	#usage()
