# Use the MySQLdb
use MySQLdb

db = MySQL.connect("localhost", "username", "password", "DATABASE")

cursor = db.cursor


