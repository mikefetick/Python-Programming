#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows
__author__ = 'Michael Fetick'
# 2/19/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 3 - Classes and Database

import AbstractClass
from AbstractClass import DatabaseProcessor


import mysql.connector
from mysql.connector import errorcode


"""
class ClassName(object):
	"""'docstring for ClassName'"""
	def __init__(self, arg):
		super(ClassName, self).__init__()
		self.arg = arg
"""

class DatabaseDriver(DatabaseProcessor):
	"""
	4.  Create a class that implements the abstract class.
	    When retrieving the data from the database, the 
	    method should populate a list of Students
	"""
	#def __init__(self):
	#	pass

	def insertStudent (self, 
		student_id, first_name, last_name, major, enrollment_date, graduation_date):
		"""
		print studentData
		sql = 'INSERT INTO `ad84270`.`students` \
		(`StudentID`,\
		`FirstName`,\
		`LastName`,\
		`Major`,\
		`GPA`,\
		`EnrollmentDate`,\
		`GraduationDate`)\
		VALUES\
		(<{StudentID: }>,\
		<{FirstName: }>,\
		<{LastName: }>,\
		<{Major: }>,\
		<{GPA: }>,\
		<{EnrollmentDate: }>,\
		<{GraduationDate: }>);'
		print "The sql is ", sql
		connectMySQL(sql)
		print "The student record has been inserted into the database."
		return sql
		"""

	def SelectStudent(self, page, offset):
		"""
		page = 0
		sql = 'SELECT `ad84270`.`students` \
		(`StudentID`,\
		`FirstName`,\
		`LastName`,\
		`Major`,\
		`GPA`,\
		`EnrollmentDate`,\
		`GraduationDate`)\
		FROM `ad84270`.`students` LIMIT page , offset'
		connectMySQL(sql)
		print "The limited set of student records is selected from the database."
		"""

def connectMySQL(sql):
	try:
		#cnx = mysql.connector.connect(user='ad84270',
		#	password='5050c748',
		#	host='linuxsandbox.coleman.edu',
		#	database='ad84270')
		cnx = mysql.connector.connect(user='sqluser',
			password='sqluser',
			host='localhost',
			database='ad84270')
		#data = ('RPG III')
		cursor = cnx.cursor()
		#cursor.execute(sql, data)
		print "The sql is ", sql
		cursor.execute(sql)
		# Execute takes three params:
		# SQLCOMMAND, PARAMS, MULTI)
		# You can populate with code or in the database
		# Comments in MySQL is a -- before it.

		for row in cursor:
			#print row[0], row[1]
			print "{0:<5} -- {1:>20}".format(row[0], row[1])

	except mysql.connector.Error as err:
		if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
			print("Something is wrong with your name or password")
		elif err.errno == errorcode.ER_BAD_DB_ERROR:
			print("Database does not exists")
		else:
			print(err)
	else:
		cnx.close

def SafeQuote(userInput):

    trimmed = userInput.strip()
    if len(trimmed) == 0:
        return trimmed

    singleQuote = "'"
    if singleQuote not in trimmed:
        return trimmed

    return trimmed.replace("'", "\\\'")
