#!/user/bin/python 	# Installed here on a Unix machine or otherwise ignored by MS Windows
# -*- coding: iso-8859-15 -*-
# 1/8/2015 Michael Fetick, 84270, Instructor: C. Oson – coson@coleman.edu, 
#                                 COM410 Python Programming, Coleman University
# Ref 1: The Quick Python Book, 2nd Ed, Manning
# Ref 2: Learning Python, 5th Ed, O'Reilly

import sys         # Import the operating system module
import os          # Import the operating system module
import os.path     # Import the operating system path modullessonse
import datetime as dt
import re          # Regular Expressions module
import traceback   # Debugging errors during runtime
import urllib      # To download a file to a local directory
import subprocess  # To call other python script
import re
import random
# from DictionaryHelper import DisplayNumber

separator = '-' * 38
test_string = "This is a test string."
exp = ' This is a test, today is Tuesday '
conversion = None

def menu1():    # Defined subroutines are typically separated by two lines
    os.system("cls")  # Clears the screen
    print ""
    print "                           Python-Lessons menu 1"
    print "                           -------------------\n"
    #                  1st class - 1/6/2015          3rd class - 1/20/2015
    print "            1a - Python programming       3a - Things indexed by keys"
    print "            1b - Strings, slice, format   3b - 'Dict' builds a Dictionary"
    print "            1c - Find, split, and strip   3c - String Comprehensions"
    print "                                               "
    #                  2nd class - 1/13/2015         4th class - 1/27/2015
    print "            2a - Collections (no arrays)  4a - Tuples"
    print "            2b - Range a slice of a list  4b - Types: Set, List, Tuple"
    print "            2c - Iterate an enumeration   4c - Regular Expressions"
    print "            2d - More Iterating           "
    print "            2e - More on Lists (methods)  5a - More RE cases"
    print "            2f - List Comprehension       "
    print "                                          "
    print "             M - More in the second half of the course"
    print ""
    print "  " + separator + separator
    # M - Whenever (M) is entered, the screen clears and redraws the menu1.


def menu2():    # Defined subroutines are typically separated by two lines
    os.system("cls")  # Clears the screen
    print ""
    print "                           Python-Lessons menu 2"
    print "                           -------------------\n"
    print "            6a -                          8a - "
    print "            6b -                          8b - "
    print "            6c -                          8c - "
    print "            6d -                          8d - "
    print "                                               "
    print "            7a -                          9a - "
    print "            7b -                          9b - "
    print "            7c -                          9c - "
    print "            7d -                          9d - "
    print "            7e -                          9e - "
    print "                                               "
    print "             R - Return to the first half of the course"
    print ""
    print "  " + separator + separator
    # M - Whenever (M) is entered, the screen clears and redraws the menu1.


def displayMenu1(option):
    while option != 'Q':  # Q - Quit - loop while the option is not this flag
        menu1()            # Call subroutine to clear the screen and redraw the menu1
        prompt = "    OPTION: " + option + "                          Q - Quit" + ("\b")*36  
        # Reposition cursor with backspace to accept the user edit
        choice = raw_input(prompt)  # input() named raw_input() in 2.X [Ref 2. pg 1146]
        if choice == '':
            choice = option
        if choice is not None:       # None is Python's other Boolean type
            os.system("MODE 80,65")  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
            menu1()                   # Call the menu1() subroutine to clear the screen and redraw the menu1
            option = choice.lower()
            if option == 'q': break  # q - Quit, 1st - break out of the if block
            # Menu options for weeks in the first half of the course
            elif option == 'm': option = '6a'; displayMenu2(option)  # to display the other menu
            elif option == '1a': option_1a(); option = '1b'  # for the next option (typical)
            elif option == '1b': option_1b(); option = '1c'
            elif option == '1c': option_1c(); option = '1d'
            elif option == '1d': option_1d(); option = '2a'
            elif option == '2a': option_2a(); option = '2b'
            elif option == '2b': option_2b(); option = '2c'
            elif option == '2c': option_2c(); option = '2d'
            elif option == '2d': option_2d(); option = '2e'
            elif option == '2e': option_2e(); option = '3a'
            elif option == '3a': option_3a(); option = '3b'
            elif option == '3b': option_3b(); option = '3c'
            elif option == '3c': option_3c(); option = '4a'
            elif option == '4a': option_4a(); option = '4b'
            elif option == '4b': option_4b(); option = '4c'
            elif option == '4c': option_4c(); option = '6a'
            else: option = ' '
            os.system("MODE 80,27")  # Restore the screen size


def displayMenu2(option):
    while option != 'Q':  # Q - Quit - loop while the option is not this flag
        menu2()            # Call subroutine to clear the screen and redraw the menu1
        prompt = "    OPTION: " + option + "                          Q - Quit" + ("\b")*36  
        # Reposition cursor with backspace to accept the user edit
        choice = raw_input(prompt)  # input() named raw_input() in 2.X [Ref 2. pg 1146]
        if choice == '':
            choice = option
        if choice is not None:       # None is Python's other Boolean type
            os.system("MODE 80,65")  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
            menu1()                   # Call the menu1() subroutine to clear the screen and redraw the menu1
            option = choice.lower()
            if option == 'q': break  # q - Quit, 1st - break out of the if block
            # Menu options for weeks in the second half of the course
            elif option == 'r': option = '1a'; displayMenu1(option)  # to display the other menu
            elif option == '6a': option_6a(); option = '6b'  # for the next option (typical)
            elif option == '6b': option_6b(); option = '6c'
            elif option == '6c': option_6c(); option = '6d'
            elif option == '6d': option_6d(); option = '7a'
            elif option == '7a': option_7a(); option = '7b'
            elif option == '7b': option_7b(); option = '7c'
            elif option == '7c': option_7c(); option = '7d'
            elif option == '7d': option_7d(); option = '7e'
            elif option == '7e': option_7e(); option = '8a'
            elif option == '8a': option_8a(); option = '8b'
            elif option == '8b': option_8b(); option = '8c'
            elif option == '8c': option_8c(); option = '9a'
            elif option == '9a': option_8a(); option = '9b'
            elif option == '9b': option_8b(); option = '9c'
            elif option == '9c': option_8c(); option = '1a'
            else: option = ' '
            os.system("MODE 80,27")  # Restore the screen size


def option_1a():
    # Introduction to the Python programming language
    # a print statement can print multiple-lines within three double-quote marks  
    print "    OPTION: 1a - The Python programming language"
    print """
    Q. Which version of Python (on Win32)... 2.7 or 3.4 ? 
    Q. Are you writing/running Python scripts on Windows or Unix?\n 
    Notes: 
    Use a text-editor with some intellisense for Python syntax...
    On Windows, use 'Sublime Text 2' (great for regular expressions)
       or another free IDE: Eclipse, Notepad++, PyCharm (JetBrains),
       PyScripter, or the MS Visual Studio Studio Plug-in= Iron Python.\n
    The Python IDLE tool is used for quick checks of syntax compilation, 
    just type 'python' at the DOS command prompt and see the IDLE prompt >>>\n
    Python code is tokenized, lexed/parsed, compiled, and then run.
    Be careful of copy-pasting the apostrophy ' from word processors because
    the code isn't checked at compile-time, it’s checked at run-time.\n
    Code blocks (if, while, for) continue to the next line after the colon :
    Correct indenting (4 spaces) is critically important for program execution
       and curly braces {} are not used for blocking-together the code."""
    # next topic
    print "  " + separator + separator
    print "    Python has dynamically-typed variables and infers the data type:"
    first = 35
    second = 2.5
    result = first + second
    print "\n    " + str(first) + " + " + str(second) + " =",
    print (result)
    print "\n    Concatinating numbers or types requires a String type-cast (conversion)"
    # Expressions can span multiple-lines but the same statement has no indentation
    print "\n    " + (str(first) + " is " + str(type(first)) + " and "
    + str(second) + " is " + str(type(second)) + " and "
    + str(result) + " is " + str(type(result)))
    # next topic
    print "\n  " + separator + separator
    print "    Here are a few examples of Python's built-in string formatting functions "
    print "    for the variable:      exp = '" + exp + "'\n"
    print "    exp.lower()          results '" + exp.lower() + "'"
    print "    exp.upper()          results '" + exp.upper() + "'"
    print "    exp.title()          results '" + exp.title() + "'"
    print "    exp.capitalize()     results '" + exp.capitalize() + "'"
    print "    exp.center(4,'*')    results '" + exp.center(4,"*") + "'"
    print "\n" * 2
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '1b'
        menu1()         # Call subroutine to redraw this menu
        option_1b()     # Call next option


def option_1b():
    # Demonstrate how the slice and format functions beautify a string for output
    # 
    print "    OPTION: 1b - Strings, slice, and format\n"
    print """    Strings are unusual because there is no char, nor an array. They are 
    made with single-quotes, double-quotes, or triple double-quotes;  
    and they are immutable. Strings can be sliced, formatted, and much more.\n
    Python has the 'slice' function that defines a subset of a collection.
    For a string, it returns a substring. The slice has a strange quirk: 
     exp[0:4] start at offset 0 but does NOT return a range of 4 characters
    Rather, it start at offset 0 and excludes everything from the 4th position.
    """
    print "    For example, exp = '" + exp + "'"
    print """                        0123456789012345678901234567890123
                       -4321098765432109876543210987654321
    """
    print "    exp[0:4]          results '" + exp[0:4] + "'"
    print "    exp[5:6]          results '" + exp[5:6] + "'"
    print "    exp[-6:-2]        results '" + exp[-6:-2] + "'"
    print "    exp[:3]           results '" + exp[:3] + "' defaults start at inclusive 0"
    print "    exp[-3:]          results '" + exp[-3:] + "' defaults to exclusive 0"
    print "    exp[-3:4]         results '" + exp[-3:4] + "'"
    print "    exp[0]            results '" + exp[0] + "'"
    print "    The len function returns the length of the collection, i.e. for a string"
    print "    str(len(exp))     results '" + str(len(exp)) + "' the count of characters"
    print "    exp[len(exp) - 1] results '" + exp[len(exp) - 1] + "'"
    print "    exp[-1]           results '" + exp[-1] + "'"
    piece = exp[-3:]
    print "    piece = exp[-3:]  results '" + (piece) + "'"
    # next topic
    print "\n  " + separator + separator
    print "    Strings can be formatted at placeholders with format specifiers, such as:" 
    print "\n\t\%s = string \t\%d = int \t\%f = float \t\%x = hex\n" 
    employee = "Taylor Swift"
    hourlyRate = 25.00
    hoursWorked = 40
    workStatement = '    Ex: %s worked %.1f hours for $%.2f pay to make $%.2f a week.' % (
        employee, hoursWorked, hourlyRate, hoursWorked * hourlyRate)
    print workStatement
    print "\n    Strings are also formatted with the 'format' expression:\n" 
    hourlyRate = 50000.00
    hoursWorked = 5
    workStatement = "    Ex: {0} now works {1} hours for ${2:,} to make ${3:,} a nite!".format(
        employee, hoursWorked, int(hourlyRate), int(hoursWorked * hourlyRate))
    print workStatement
    print "\n" * 3
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '1c'
        menu1()         # Call subroutine to redraw this menu
        option_1c()     # Call next option


def option_1c():
    # Demonstrate how the slice function copies a substring (piece of the string)
    # 
    print "    OPTION: 1c - Find, split, and strip"
    print """
    A pattern of text can be found in a string by using the 'find' method. 
    If a substring isn't found, the find method will return a -1 error. 
    This is better than the 'index' method that returns nothing at all.
    Find returns the starting position of the found pattern.
    """
    print "                        0123..."
    print "    for example, exp = '" + exp + "'"
    print "                           ^                      ...-4321"
    print "    exp.find('is') result: " + str(exp.find('is'))    # returns the index
    print "\n    To just determine if a substring exists... (True/False)\n"
    print "    exp._contains_('is') results '" + str(exp.__contains__('is')) + "'"
    print "    exp.startswith('T')  results '" + str(exp.startswith('T')) + "'"
    print "    exp.endswith('T')    results '" + str(exp.endswith('T'))
    # next topic
    print "\n  " + separator + separator
    print """    Strings of text can be 'split' apart, into the words (or tokens) 
    between whitespace; this is called tokenizing the string.
    """
    print "                         0    1  2 3     4     5  6 "
    print "    for example, exp = '" + exp + "'"
    print "                         -7   -6 -5-4    -3    -2 -1 \n"
    print "    exp.split(' ') returns:"
    tokens = exp.split(' ')
    print "    " + str(tokens)
    # next topic
    print "\n  " + separator + separator
    print "    The 'strip' command removes the whitespace of tabs '\\t', blanks 'blank', "
    print "    new lines '\\n', verticle bars '|', and the ASC(12) (form feeds).\n"
    print "    strip(exp) results '" + str.strip(exp) + "'\n"
    print "    The 'strip' method removes all leading and trailing whitespaces.\n"
    print "    exp.strip() results '" + exp.strip()
    print "\n" * 3
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2a'
        menu1()         # Call subroutine to redraw this menu
        option_2a()     # Call next option


def option_2a():
    # Python's 'Collections' (no arrays)
    # 
    print "    OPTION: 2a - Collections (no arrays)"
    print """
    Python has no 'array' but it has 'collections' like list, map, hash, etc. 
    Similar to the way other languages iterate through an array -\n 
        for ( int I=0, max=array.length; i<max; I++ ) {
            // do something
        }\n
    Python iterates through a 'list' for [eachItem] with the 'in' keyword -\n
        for eachItem in list    # ('eachItem' is a user-defined variable)
            Print eachItem """
    # next topic
    print "  " + separator + separator
    print "    Also, other languages have requirements of arrays -"
    print "        1) index >= 0"
    print "        2) items are the same data type\n"
    print "    Python's 'list' can contain elements of different data types,"
    print "    for example:        ---0--- -1- -2-  --3-- --4-- ---5---  --6-\n"
    print "        genericList = [ [1,2,3], 1, 'n', True, None, 'Hello', 7.99 ]\n"
    genericList = [[1,2,3],1,'n',True,None,'Hello',7.99]
    print "    The elements are accessed by a [slice] that is defined by an optional "    
    print "    starting value and an optional ending value; optional with defaults of 0. \n"    
    print "        genericList[-1]  returns " + str(genericList[-1]) + "     # the last element "
    print "\n    This slice starts at the default position 0 and excludes from position 3 \n"
    print "        genericList[:3]  returns " + str(genericList[:3]) + "\n"
    print "        len(genericList) returns " + str(len(genericList)) + '        # the count '
    print "\n" * 8
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2b'
        menu1()         # Call subroutine to redraw this menu
        option_2b()     # Call next option


def option_2b():
    # Demonstrate how the range function copies a slice from a list
    # 
    print "    OPTION: 2b - Range a slice of a list\n"
    print "    Python's 'range' function works like a slice but it's attributes of "
    print "    start and stop (are not optional) and the step (is optional).\n"
    print "        firstTenNumbers = range(1, 11)    # Note: the 11 is excluded!\n"
    firstTenNumbers = range(1, 11)
    print "        range(1, 11)          returns " + str(firstTenNumbers)
    print "\n    The optional third parameter of -5 indicates a step amount:\n"
    print "        moreNumbers = range(100, 80, -5)\n"
    moreNumbers = range(100, 80, -5)
    print "        range(100, 80, -5)   returns " + str(moreNumbers)
    # next topic
    print "\n  " + separator + separator
    print "    The 'reverse' function can be used inline or not inline.\n"
    someValues = ['abc', 'def', 'ghi', 'jkl', 'mno']
    print "        print someValues     returns " + str(someValues)
    print "        someValues.reverse() # inline"
    someValues.reverse()
    print "        print someValues     returns " + str(someValues)
    print "\n        reversed(someValues) # not inline"
    reversed(someValues)
    print "        print someValues     returns " + str(someValues)
    print "        reverse_d = reversed(someValues)"
    reverse_d = reversed(someValues)
    print "        print reverse_d      returns " + str(reverse_d)
   # next topic
    print "\n    But itererating a list with the 'reverse' function inline, of either: "
    print ''
    print "        for eachElement in (list.reverse(someValues)):"
    print "            print eachElement, \n"
    print "        for eachElement in (someValues.reverse()):"
    print "            print eachElement, \n"
    print "        results 'TypeError: 'NoneType' object is not iterable'"
    print "        and this same result occurs with IDLE"
    print "\n" * 3
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2c'
        menu1()         # Call subroutine to redraw this menu
        option_2c()     # Call next option


def option_2c():
    # Demonstrate how to iterate through an enumeration
    # 
    print "    OPTION: 2c - Iterate an enumeration\n"
    print "    Iterate through a loop while decrementing the count of elements"
    print ''
    print "        someValues = ['abc', 'def', 'ghi', 'jkl', 'mno'] "
    print "        elementToProcess = len(someValues) - 1 "
    print "        loop = 0 \n"
    print "        while loop < elementToProcess:"
    print '            # print the index and the value'
    print '            print "{0} +> {1}".format(loop, someValues[loop]),'
    print "            loop += 1"
    print "                         # Print on the same line by using a ^ comma: \n"
    someValues = ['abc', 'def', 'ghi', 'jkl', 'mno']
    elementToProcess = len(someValues)
    elementToProcess = elementToProcess - 1
    loop = 0
    while loop < elementToProcess:
        # print the index and the value
        print "        {0} +> {1}".format(loop, someValues[loop]),   
        loop += 1
    print ''
    # next topic
    print "\n  " + separator + separator
    print "    Iterate through a loop for the index of every element in a list"
    print ""
    print "        for (index, everyNumber) in someValues:"
    print '            # print the index and the value'
    print '            print "{0} +> {1}".format(index, everyNumber)\n'
    print "        Results: ValueError('too many values to unpack')"
    # next topic
    print "\n  " + separator + separator
    print "    Iterate through an inline list \n"
    print "        for food in ('pate', 'cheese', 'crackers', 'margarine', 'yogurt'):"
    print "            if food == 'yogurt':"
    print "                print 'yogurt encountered'"
    print "                break"
    print "        else:  # counter to the for loop, not the if statement"
    print "            print 'There is no yogurt'\n"
    print "        Results: ",
    for food in ('pate', 'cheese', 'crackers', 'margarine', 'yogurt'):
        if food == 'yogurt':
            print 'yogurt encountered'
            break
    else:  # counter to the for loop, not the if statement
        print 'There is no yogurt'
    print "\n" * 5
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2d'
        menu1()         # Call subroutine to redraw this menu
        option_2d()     # Call next option


def option_2d():
    # Demonstrate how to iterate through an enumeration
    # 
    print "    OPTION: 2d - More Iterating\n"
    print "    Iterate for only 'odd' index numbers of elements in a list\n"
    print "        numbers = [7, 15, 22]"
    print "        for everyNumber in numbers:"
    print "            if everyNumber % 2 != 0:    # want to skip any even numbers"
    print "                print everyNumber\n"
    print "        Results:",
    numbers = [7, 15, 22]
    for everyNumber in numbers:
        if everyNumber % 2 != 0:    # want to skip any even numbers
            print " " + str(everyNumber),
    # next topic
    print "\n\n  " + separator + separator
    print "    Iterate through the list, through each element, for each character:\n"
    lastNames = ['Douglass', 'Jefferson', 'Williams', 'Frank', 'Thomas']
    print "        lastNames = " + str(lastNames)
    print "\n        print 'lastNames: (0)'.format(lastnames[0])"
    print "        print 'First character of last name: (0)'.format(lastNames[0][0])"
    print "        for eachElement in lastNames:"
    print "            for eachCharacter in EachElement:"
    print "                print eachCharacter,\n"
    print "        Results:"
    print '        lastNames: {0}'.format(lastNames[0])
    print '        First character of last name: {0}'.format(lastNames[0][0])
    print '       ',
    for eachElement in lastNames:
        for eachCharacter in eachElement:
            print eachCharacter,
    # next topic
    print "\n  " + separator + separator
    print "    Iterate through a list of lists \n"
    listOfLists = [['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]
    print "        listOfLists = " + str(listOfLists)
    print "        for eachList in listOfLists:"
    print "            for eachElement in eachList:"
    print "                print eachElement,\n"
    print "        Results:      ",
    for eachList in listOfLists:
        for eachElement in eachList:
            print eachElement,
    print "\n" * 6
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2e'
        menu1()         # Call subroutine to redraw this menu
        option_2e()     # Call next option


def option_2e():
    # Demonstrate how to iterate through an enumeration
    # 
    print "    OPTION: 2e - More on Lists (methods)\n"
    print "    Alter a list, ref: https://docs.python.org/2/tutorial/datastructures.html\n"
    print "        numberList = [5, 15, 15, 25, 35];  print numberList"
    numberList = [5, 15, 15, 25, 35]
    print "        " + str(numberList)
    print "\n        numberList.append(45);  print numberList      # append (add at end)"
    numberList.append(45)
    print "        " + str(numberList)
    print "\n        numberList.insert(0, -5);  print numberList   # insert (add here)"
    numberList.insert(0, -5)
    print "        " + str(numberList)
    print "\n        numberList.pop();  print numberList           # pop (remove the last)"
    numberList.pop()
    print "        " + str(numberList)
    print "\n        numberList.pop(0);  print numberList          # pop (remove here)"
    numberList.pop(0)
    print "        " + str(numberList)
    print "\n        # Python has no push but can insert the item, at the end of the list"
    print "        numberList.insert(len(numberList), 55)        # inserts here"
    numberList.insert(len(numberList), 55)
    print "        " + str(numberList)
    print "\n        numberList.insert(-1, 65);  print numberList  # 2nd to last, not last?"
    numberList.insert(-1, 65)
    print "        " + str(numberList)
    print "\n        del numberList[3];  print numberList          # deletes 25"
    del numberList[3]
    print "        " + str(numberList)
    print "\n        if 15 in numberList:          # Always check for the existence first.."
    print "            numberList.remove(15)         # only the first instance is removed"
    if 15 in numberList:
        numberList.remove(15)
    print "        " + str(numberList)
    print "\n        del numberList[:3];  print numberList     # deletes the 1st 3 elements"
    del numberList[:3]           # delete the first three elements
    print "        " + str(numberList)
    print "\n" * 6
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '2f'
        menu1()         # Call subroutine to redraw this menu
        option_2f()     # Call next option


def divide2Numbers(a, b):
    if b == 0:
        return 0
    return a/b


def findAll(L, value, start = 0):
    # generator version
    i = start -1
    try:
        i = L.index(value, I + 1)
        yield I    # the return result of final is thee current list
    except ValueError:
        pass
    for eachItem in findAll(numbers, 5):
        print eachItem


def option_2f():
    # Demonstrate how List Comprehension works
    # 
    print "    OPTION: 2f - List Comprehension\n"
    print "    List Comprehension computes mathematical expressions inline\n"
    numberList = [1, 2, 3, 4, 5]
    print "        numberList = " + str(numberList)
    print "        listComprehension = [x * x for x in numberList]  # each number squared"
    listComprehension = [x * x for x in numberList]
    print "        print listComprehension"
    print "    " + str(listComprehension)
    print "                                                           # cube odd numbers"
    print "        pythonianWay = [x * x * x for x in numberList if x % 2 == 1]"
    pythonianWay = [x * x * x for x in numberList if x % 2 == 1]
    print "        print pythonianWay"
    print "    " + str(pythonianWay)
    # next topic
    print "\n  " + separator + separator
    print "        queue = [];  customers = ['Joe', 'Jane', 'Joanne', 'Jim', 'Jen']\n"
    print "        for nextInline in customers:"
    print "            currentCustomer = nextInline"
    print "            queue.append(currentCustomer)"
    print "        queue.pop(0)"
    queue = []
    customers = ['Joe', 'Jane', 'Joanne', 'Jim', 'Jen']
    for everyCustomer in customers:
        currentCustomer = everyCustomer
        queue.append(currentCustomer)
    queue.pop(0)
    print "        print 'The number of people in the queue is: {0}'.format(len(queue))\n"
    print '    The number of people in the queue is: {0}'.format(len(queue))
    # next topic
    print "\n  " + separator + separator
    print "    from random import randint"
    print "        print randint(2, 9)    # Inclusive"
    from random import randint
    print "    " + str(randint(2, 9))    # Inclusive
    print "        numbers = []"
    numbers = []
    print "        for eachItem in range(1, 21):"
    print "            numbers.append(randint(1, 11))"
    for eachItem in range(1, 21):
        numbers.append(randint(1, 11))
    print "        print numbers"
    print "    " + str(numbers)    
    print "\n        value = 5"
    print "        try:"
    print "            position = numbers.index(value)"
    print "        except ValueError:"
    print "            position = -1"
    print "        print 'The position is: {0}'.format(position)"
    value = 5
    try:
        position = numbers.index(value)
    except ValueError:
         position = -1
    print '    The position is: {0}'.format(position)
    print "\n  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    # if user_input.lower() != 'm':   # Code can be commented-out with an if block
    #     pass    # The pass keyword can provide the expected indentation for a block
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '3a'
        menu1()         # Call subroutine to redraw this menu
        option_3a()     # Call next option


def option_3a():
    # Demonstrate what and how things are indexed by keys
    # 
    print "    OPTION: 3a - Things indexed by keys"
    print """
    Things indexed by keys include a dictionary, hash table, .net arrays, and 
    name-value pairs but they cannot have elements with duplicate keys.\n 
    An ordered list can be searched by comparing a name to the median element, 
    dividing the list in half, and repeating the process to diminish the size 
    of the list and eventually finding the name. This divide/conquer method  
    is done by a factor of n/2 and is called a binary search. 
    The radix is the base of the number, e.g. 2\n 
    The Big 'O': O() indicates the efficency of a search method.\n 
    O(n) -> o(n2)       Ex: 42,000 U.S. zip codes require (2^16) 16 searches
    2^20 = 10e7 = 1M      
    2^21 = 10e8 = 2M        And this city's telephone directory lists names, 
    2^22 = 10e9 = 4M        orderly A..Z and has about 8 million entries, so
    2^23 = 10e10 = 8M  <-   a name/number can be found in (2^23) 23 searches
    """
    print "    communities = {'92109': 'Pacific Beach', ...., '92101': 'Downtown'}"
    communities = {
        '92109': 'Pacific Beach',
        '92108': 'Mission Valley',
        '91941': 'La Mesa',
        '92126': 'Mira Mesa',
        '92101': 'Downtown'}
    print '\n    The number of items in my dictionary: {0}'.format(len(communities))
    print "\n        for key, value in communities.items():"
    print "            print '[{0}] => {1}'.format(key, value)\n"
    for key, value in communities.items():
        print '    [{0}] => {1}'.format(key, value)
    # next topic
    print "\n    To delete a key, first lookup the key to see if it exists...\n"
    print "        current_key = '92108'"
    print "        if current_key in communities:"
    print "            print '{0} is in the dictionary'.format(current_key)"
    print "            del communities['92110']"
    print "        else:"
    print "            print '{0} is not in the dictionary'.format(current_key)"
    current_key = '92108'
    if current_key in communities:
        print '    {0} is in the dictionary'.format(current_key)
        del communities[current_key]
    else:
        print '    {0} is not in the dictionary'.format(current_key)
    print "\n  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '3b'
        menu1()         # Call subroutine to redraw this menu
        option_3b()     # Call next option


def option_3b():
    # 
    # 
    print "    OPTION: 3b - 'Dict' builds a Dictionary\n"
    print "    communities = {'92109': 'Pacific Beach', ...., '92101': 'Downtown'}"
    communities = {
        '92109': 'Pacific Beach',
        '92108': 'Mission Valley',
        '91941': 'La Mesa',
        '92126': 'Mira Mesa',
        '92101': 'Downtown'}
    print "        communities.setdefault('00000', '')"
    communities.setdefault('00000', '')
    print "\n        print type(communities.keys())"
    print "    " + str(type(communities.keys()))
    print "\n        print communities.keys()"
    print "    " + str(communities.keys())
    print "\n        print communities.values()"
    print "    " + str(communities.values())
    print "\n        for key, value in communities.items:"
    print "            print '[{0}] => {1}'.format(key, value)"
    for key, value in communities.items():
        print '    [{0}] => {1}'.format(key, value)
    # next topic
    print "\n  " + separator + separator
    print "    It's NOT good practice to use an exception to control your logic, e.g.:\n"
    print "        contents = {'eggs': 2, 'cheese': 5, 'grapes': 2, 'avocado': 5}"
    contents = {'eggs': 2, 'cheese': 5, 'grapes': 2, 'avocado': 5}
    print "        try:"
    print "            if contents['avocado'] > 0:"
    print "                print 'Let\'s eat an avocado.'"
    print "        except KeyError:"
    print "            print 'The key does not exists'"
    print "        except TypeError:"
    print "            pass"
    print "\n   ",
    try:
        if contents['avocado'] > 0:
            print 'Let\'s make an avocado omellete'
    except KeyError:
        print 'The key does not exists'
    except TypeError:
        pass
    # print "        return_results, the_keys = return_keys(some_dictionary)"
    print "\n        return_results, the_keys = return_keys(contents)"
    print "        print the_keys\n"
    # return_results, the_keys = return_keys(some_dictionary)
    return_results, the_keys = return_keys(contents)
    print "   ",
    print the_keys
    print "\n  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '3c'
        menu1()         # Call subroutine to redraw this menu
        option_3c()     # Call next option


def return_keys(a_dictionary):
    if isinstance(a_dictionary, dict):
        return True, a_dictionary.keys()
    return False, []


def do_something_silly(arg1):
    param1 = arg1
    param2 = 5 * 5
    return param1  # Python allows us to keep our place


def simple_generator_function():
    yield 1
    yield 2
    yield 3


def square(number):
    return number * number


def cube(number):
    return number * number * number


def display_number(number, radix=10, whatever='whatever'):
    if radix not in conversion.keys():  # Dictionary
        return 'Error'
    conversion = {
        2:  str(bin(number)),
        8:  str(oct(number)),
        10: str(number),
        16: format(number, '02x')
    }
    if whatever == 'whatever':
        whatever = 'Not used'
    else:
        whatever = 'Used'
    return conversion[radix], whatever


def display_number_old_too(number, radix=10):
    if radix not in conversion.keys():  # Dictionary
        return 'Error'
    conversion = {
        2:  str(bin(number)),
        8:  str(oct(number)),
        10: str(number),
        16: format(number, '02x')
        }
    return conversion[radix]


def display_number_old(number, radix=10):
    formatted_results = ''
    if radix not in valid_radices:
        return 'Error'

    conversion = {
        2:  str(bin(number)),
        8:  str(oct(number)),
        10: str(number),
        16: format(number, '02x')
        }
    if radix == 16:
        formatted_results = format(number, '02x')
    if radix == 10:
        formatted_results = str(number)
    if radix == 8:
        formatted_results = str(oct(number))
    if radix == 2:
        formatted_results = str(bin(number))
        # formatted_results = str(bin(number)[2:]
    return formatted_results


def option_3c():
    # Demonstrate how to use String Comprehension
    # 
    print "    OPTION: 3c - String Comprehensions\n"
    print """    User-defined functions:
        return_keys(a_dictionary)
        do_something_silly(arg1)
        display_number(number, radix=10, whatever='whatever')
        display_number_old_too(number, radix=10)
        display_number_old(number, radix=10)\n        
    Helper methods help us by performing actions on certain data types, 
    i.e. 'dictionary helper' which has reference to the function helper.\n
    Plan: - Have a dictionary helper
          - Function DisplayNumber
          - Create a file called Main (a driver) that calls DisplayNumber
    """
    print "  " + separator + separator
    print "    User-defined functions:  simple_generator_function() remembers  "
    print "    where/what was returned previously, with the 'yield' function.\n"
    print "    Items 'in' a sequence use 'next' and it's not an array...\n"
    print "        for eachItem in simple_generator_function():"
    print "            print eachItem"
    print "   ",
    for eachItem in simple_generator_function():
        print str(eachItem) + " ",
    # next topic
    print "\n\n        our_generator = simple_generator_function()"
    our_generator = simple_generator_function()
    print "        next(our_generator) result: " + str(next(our_generator))
    print "        next(our_generator) result: " + str(next(our_generator))
    # next topic
    print "\n  " + separator + separator
    print "    User-defined functions:  square(number), cube(number)\n"
    print "    print square(10)    " + str(square(10))
    print "    print cube(10)      " + str(cube(10))
    conversion = 'whatever'
    #print display_number(255, 16)
    #print display_number_old(255, 16)
    #print display_number_old_too(255, 16)
    #results, what_is_whatever = display_number(whatever='Who are you', number=55)
    #print 'Results is: {0} and whatever is: {1}'.format(results, what_is_whatever)
    print "\n" * 6
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '4a'
        menu1()         # Call subroutine to redraw this menu
        option_4a()     # Call next option


def option_4a():
    # Demonstrate how to use Tuples
    # 
    print "    OPTION: 4a - Tuples\n"
    print "    Python uses () parentheses for tuples\n"
    print "    Tuples are immutable - cannot modify the contents of a tuple"
    a = {1, 2}
    b = [1, 2]
    c = (1, 2)
    tuple1 = ('one', 'two', 'three', 4, 1997, 2000);
    print "        tuple1 = " + str(tuple1)
    print "        tuple1[0] = 'five'   TypeError(does not support item assignment)"
    #tuple1[0] = 'five'
    print "        print tuple1[0]      Results: ",
    print tuple1[0]
    print ''

    #tuple2 = (1, 2, 3, 4, 5);
    #print "    tuple2 = " + str(tuple2)
    #tuple3 = "a", "b", "A", "Z";
    #print "    tuple3 = " + str(tuple3)
    emptyTuple = ();
    print "    emptyTuple = " + str()
    singleValueTuple = (2, )
    print "    singleValueTuple = " + str(singleValueTuple)

    print "\n    You can use the slice notation (will be a tuple of a tuple)"
    print "        print tuple1[0:3]    Results: " + str(tuple1[0:3])
    print "\n    You can't change a tuple but you can create a copy of a tuple."
    print "        first = (33, 44, 55);  second = (66,);  third = first + second"
    first = (33, 44, 55)
    second = (66,)
    third = first + second
    print "        print third    Results: " + str(third)
    print "\n        brandNewTuple = (10, 20, 30)"
    brandNewTuple = (10, 20, 30)
    print "        print len(brandNewTuple)          Results: " + str(len(brandNewTuple))
    
    print "        print (5, 9, 4) + (15, 19, 14)    Results: " + str((5, 9, 4) + (15, 19, 14))
    
    print "        if 20 in brandNewTuple:"
    print "            print 'The number is in brandNewTuple'"
    if 20 in brandNewTuple:
        print '    The number is in brandNewTuple'
    print "\n        for eachTupleItem in brandNewTuple:"
    print "            print eachTupleItem * 2       Results: ",
    for eachTupleItem in brandNewTuple:
        print str(eachTupleItem * 2) + "  ",

    print "\n    Duplicate instances of a tuple."
    print "        print (5, ) * 4                   Results: " + str((5, ) * 4)

    print "\n    The two functions of data type Tuple is the 'min' and 'max'"
    print "        min(brandNewTuple)    Results: " + str(min(brandNewTuple))
    print "        max(brandNewTuple)    Results: " + str(max(brandNewTuple))
    print "\n    Using a tuple to create a new tuple"
    print "        tuple(range(5, 15))    Results: " + str(tuple(range(5, 15)))

    print "\n    Tuples are faster than using a List. It has a smaller big O.\n"
    print "    Tuples are also safer because a user cannot change the data"
    print "    (they could change data in a list)"
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '4b'
        menu1()         # Call subroutine to redraw this menu
        option_4b()     # Call next option


def option_4b():
    # Compare Types: Set, List, Tuple
    # 
    print "    OPTION: 4b - Types: Set, List, Tuple\n"
    a = {1, 2}
    b = [3, 4]
    c = (5, 6)
    print "    Use {} curly braces  for a 'set'  a = " + str(a) + "  type(a): " + str(type(a))
    print "    Use [] brackets     for a 'list'  b = " + str(b) + "       type(b): " + str(type(b))
    print "    Use () parentheses for a 'tuple'  c = " + str(c) + "       type(c): " + str(type(c))
    print "\n    A tuple can convert a list into a tuple"
    print "        b = [1, 2]"
    print "        c = (1, 2)"
    print "        print id(b)             Results: " + str(id(b))
    print "        print a.__sizeof__()    Results: " + str(a.__sizeof__())
    print "        print b.__sizeof__()    Results: " + str(b.__sizeof__())

    print "\n        a = tuple(range(1000))"
    print "        b = list(range(1000))"
    a = tuple(range(1000))
    b = list(range(1000))

    print "        print id(a)             Results: " + str(id(a))
    
    print "\n        b = [1, 2]    # I'm changing the list now because it is mutable"
    b = [1, 2]
    print "        b[0] = 3"
    b[0] = 3
    print "\n        a = (1, 2)"
    a = (1, 2)
    print "        a[0] = 3"
    print "        # results error because we're trying to change the value of a tuple."
    #a[0] = 3   
    print "        print a   Results: " + str(a)
    print "\n    Python has the id function by using 'append' "
    print "        b.append(5)"
    b.append(5)
    print "        print b   Results: " + str(b)
    #print "    # result 8024, 9088"    
    #print "    sweet"
    #print "    sweeeeet"
    #print "    #^swe{2,4}t  # five e's will not match"
    #print "    swewet  # matches"
    print "\n" * 12
    print "\n  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '4c'
        menu1()         # Call subroutine to redraw this menu
        option_4c()     # Call next option


def IsValidNumber(number, pattern):
    # match only works with the beginning of the string
    # search finds matches throughout the string

    if len(pattern) == 0:
        return True

    isMatch = re.search("^\d+\.\d+$")  # isMatch is now an object
    # There are four types of function parameters
    if isMatch is None:
        return True
    return true
    # print IsValidNumber(59.999, "^\d+\.\d+$")


def option_4c():
    # Demonstrate how to use Regular expressions
    # 
    print "    OPTION: 4c - Regular expressions (RE)\n"
    print """    https://docs.python.org/3/library/re.html?highlight=\%20expressions
    RE is used to match a \string pattern\ to find or manipulate strings.\n 
    With Python's 'raw string notation' backslashes are not handled in any 
    special way in a string literal prefixed with r"literal".\n 
    Some special characters matches:
    . Dot matches any character except a newline \\n.
    ^ Caret (line anchors) matches the start of the line, in MULTILINE after each newline.
    $ Dollar matches the end of the string or just before the newline...
    | The alternation symbol is the vertical bar and means this or that; e.g. ^(Je|Geo)ffrey$
    * matches 0 or more reps of preceding RE, ab* will match a, ab, abb...
    + matches 1 or more reps of preceding RE. ab+ will match ab, abb...
    ? matches 0 or 1 reps of preceding RE. ab? will match either a or ab.
    *?, +?, ?? Adding '?' after the qualifier makes it non-greedy or minimal; 
    *, +, and ? qualifiers are all greedy; matching as much as possible.
    (?=...), ?> are lookahead assertions\n 
    Parentheses are used for grouping parts of the RE.
    {} indicates a min and/or max range; e.g. ^swe{2,4}t two-four e's match 
    ^[0-9A-F]+$   # The $ means the last character must also match
    [] ... range of contiguous characters,
    [] ... non-contiguous characters
    () group characters
    () or capture variables.

    Four character classes: 
    \s \S indicates white space: (blank "", tab "\\t", new line "\\n" character)
    chr(32), chr(9), chr(13), chr(10) 
    \w \W means any alpha-numeric value: (A-Z, a-z, 0-9) (lowercase w)
    \d \D means any digit [0-9]
    \\b \\B means word boundary
    \\E,\\L,\\u (Unique to Perl)
    Regex is typically used for data validation
\n    Full-featured methods for compiled RE: prog = re.compile(pattern, flag=0), 
                                           result = prog.match(string)"""
    print '        dataStr = "5"'
    print '        pattern = "^\d+$"'
    print '        prog = re.compile(pattern)'
    print '        result = prog.match(dataStr)'
    print '        print result'
    dataStr = "5"
    pattern = "^\d+$"
    decimalPattern = "^\d+\.\d+$"
    prog = re.compile(pattern)
    result = prog.match(dataStr)
    print "    " + str(result)
    print "\n" * 1
    print "  " + separator + separator
    print "           Press the 'M' then 'Enter' keys to return to the main menu  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'r':
        option = '6a'
        displayMenu2(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'm':
        option = '1a'
        menu1()         # Call subroutine to redraw this menu
        option_1a()     # Call next option


def option_5a():
    # Demonstrate how 
    #   
    print "    OPTION: 5a - More RE cases"
    print """
    Credit cards (cc) are numbers.
    1. Create a regex to validate months Jan to separator
    \d is 0..9 and won't work, so [1-9]. For the optional 0 character: 0?[1-9]
    And the optional months Oct to Dec: 0?[1-9] | 1[0-2]
    For the days in a month: 0?[1-9] | [12]\d | 3[01]

    Password: 8-20 digits, an uppercase, a lowercase, and a special character.
    8 characters
    upper = range(ord(65), ord(92)) # it has upper, lower, or digit.
    password = 'Testhhg7'
    if password[0] in upper:
        # valid
    
    # With regex:
    upper = range(ord(65), ord(92)) # it has upper, lower, or digit.
    password = 'Testhhg7'
    


    The look ahead: ?> 

    JavaScript:
    function ValidateField (str) {
        # Search s/ and replace / start ^ to end $, whitespace \s (one or more +):
        str = s/^\s+|\s+$//;
    }

    Regex to capture a name. First name separeted from last name with whitespace
    Then, revert the order.
    1. first name: ^\w+\s\w+$   # \w is alphanumeric
        $1 (notation to capture variables in many prog lang but not Python)
        2. Capture groups of variable swith parentheses

    Revert the order:
    Find:    ^(\w+)\s(w+)$
    Replace: $2, $1

    But people with three names, we'll use:
    Find:    ^((\w+\s)+)(\w+)$
    Replace: $2, $1



    John Doe
    Tommy Lee Jones
    Leticia Lopez
    Chen Zu


    Change uppercase words to title case with the \L:
    Find:    ^([A-Z])([A-Z]+)$
    Replace: $1\L$2

    SQL Join Types: 
    - inner join (default)
    - Left Join, Left Outer-join
    - Right Join, Right Outer-join
    - self join (classify data at a hierarchy level)
    - cross join

    To create insert statements
    1. Create a teble 
    2. Capture names
    Find:    ^\w+$
    Replace: CREATE INTO FirstNames (FirstName) VALUES ('1')
    varchar use ' quotes '

    Find:    ^\w([A-Z])([A-Z]+)$
    Replace: CREATE INTO LastNames (LastName) VALUES ('1')

    CREATE TABLE FirstNames
    (
        FirstName `VARCHAR(32)
    )
    
    CREATE TABLE LastNames
    (
        LastName `VARCHAR(32)
    )

    Use cross join to generate data. It is a Cartesian join
    You multiple number of rows of each table.

    SELETE FirstName, LastName
    FROM FirstNames CROSS JOIN LastNames



    Will be given two files: area codes and some regions
    Area Cosdes file:
    650 - San Jose - Sunnyvales
    205 - Alabama
    919 - North Caralina, Charlotte

    1. Use RE to load dictionary from key (arae code) and value (everything on the other side of the hyphen)
    2. Load dictionary with the key, value pairs
    3. Validate the phone numbers file with RE of: 
    2057193782
    4. Extract area code
    5. Do a dictionary lookup
    6. Print the corresponding region


    Need: 
    1. Formatted phone number
    2. Count of valid phone numbers
    3. Count of invalid phone numbers
    4. Count of valid phone numbers but no corresponding area code
    5. All saved to a file. Output file spec is o webclass.



    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    print "\n" * 2
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '5b'
        menu2()         # Call subroutine to redraw this menu
        option_5b()     # Call next option


def option_5b():
    # Demonstrate how 
    #   
    print "    OPTION: 5b - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '5c'
        menu2()         # Call subroutine to redraw this menu
        option_5c()     # Call next option


def option_5c():
    # Demonstrate how 
    #   
    print "    OPTION: 5c - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6a'
        menu2()         # Call subroutine to redraw this menu
        option_6a()     # Call next option


def option_6a():
    # Demonstrate how 
    #   
    print "    OPTION: 6a - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6b'
        menu2()         # Call subroutine to redraw this menu
        option_6b()     # Call next option


def option_6b():
    # Demonstrate how 
    #   
    print "    OPTION: 6b - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6c'
        menu2()         # Call subroutine to redraw this menu
        option_6c()     # Call next option


def option_6c():
    # Demonstrate how 
    #   
    print "    OPTION: 6c - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6d'
        menu2()         # Call subroutine to redraw this menu
        option_6d()     # Call next option


def option_6d():
    # Demonstrate how 
    #   
    print "    OPTION: 6d - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '7a'
        menu2()         # Call subroutine to redraw this menu
        option_7a()     # Call next option


def option_7a():
    # Demonstrate how 
    #   
    print "    OPTION: 7a - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '7b'
        menu2()         # Call subroutine to redraw this menu
        option_7b()     # Call next option


def option_7b():
    # Demonstrate how 
    #   
    print "    OPTION: 7b - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '7c'
        menu2()         # Call subroutine to redraw this menu
        option_7c()     # Call next option


def option_7c():
    # Demonstrate how 
    #   
    print "    OPTION: 7c - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '7d'
        menu2()         # Call subroutine to redraw this menu
        option_7d()     # Call next option


def option_7d():
    # Demonstrate how 
    #   
    print "    OPTION: 7d - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '7e'
        menu2()         # Call subroutine to redraw this menu
        option_7e()     # Call next option


def option_7e():
    # Demonstrate how 
    #   
    print "    OPTION: 7e - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '8a'
        menu2()         # Call subroutine to redraw this menu
        option_8a()     # Call next option


def option_8a():
    # Demonstrate how 
    #   
    print "    OPTION: 8a - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '8b'
        menu2()         # Call subroutine to redraw this menu
        option_8b()     # Call next option


def option_8b():
    # Demonstrate how 
    #   
    print "    OPTION: 8b - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '8c'
        menu2()         # Call subroutine to redraw this menu
        option_8c()     # Call next option


def option_8c():
    # Demonstrate how 
    #   
    print "    OPTION: 8c - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '8d'
        menu2()         # Call subroutine to redraw this menu
        option_8d()     # Call next option


def option_8d():
    # Demonstrate how 
    #   
    print "    OPTION: 8d - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '9a'
        menu2()         # Call subroutine to redraw this menu
        option_9a()     # Call next option


def option_9a():
    # Demonstrate how 
    #   
    print "    OPTION: 9a - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '9b'
        menu2()         # Call subroutine to redraw this menu
        option_9b()     # Call next option


def option_9b():
    # Demonstrate how 
    #   
    print "    OPTION: 9b - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '9c'
        menu2()         # Call subroutine to redraw this menu
        option_9c()     # Call next option


def option_9c():
    # Demonstrate how 
    #   
    print "    OPTION: 9c - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6d'
        menu2()         # Call subroutine to redraw this menu
        option_6d()     # Call next option


def option_9d():
    # Demonstrate how 
    #   
    print "    OPTION: 9d - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '9e'
        menu2()         # Call subroutine to redraw this menu
        option_9e()     # Call next option


def option_9e():
    # Demonstrate how 
    #   
    print "    OPTION: 9e - "
    print """
    -descriptive text- 
    """
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    # next topic
    print "\n  " + separator + separator
    print "    -instructive text-"
    print "        -code-"
    # run code here
    print "\n" * 29
    print "  " + separator + separator
    print "           Press the 'R' then 'Enter' keys to return to menu 2  "
    prompt = "                 or press the 'Enter' key for the next topic... "
    user_input = raw_input(prompt)
    if user_input.lower() == 'm':
        option = '1a'
        displayMenu1(option)  # Call subroutine to redraw other menu with first option
    elif user_input.lower() != 'r':
        option = '6a'
        menu2()         # Call subroutine to redraw this menu
        option_6a()     # Call next option


def main():
    os.system("MODE 80,27")  # Restore the screen size
    option = '1a'  # Default menu1 option '1a'
    displayMenu1(option)


try:    # Debugging with Outer try Statement replaces Python's Top-Level Exception Handling [Ref 2. pg 1149]
    main()
except EOFError, e:	 # raw_input() raises a built-in EOFError Exception Signal (not an error) [Ref 2. pg 1146]
    assert e
except:
    print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])    # Display all exceptions without program termination
    traceback.print_exc()										# Display the call stack [Ref 1. pg 1150]
    raw_input("        Press the Enter key to exit")
