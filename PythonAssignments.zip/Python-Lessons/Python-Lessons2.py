#!/user/bin/python 	# On a Unix machine, this is where Python is installed. Otherwise ignored by MS Windows
# -*- coding: iso-8859-15 -*-
# 1/8/2015 Michael Fetick, 84270, Instructor: Chris Oson – coson@coleman.edu, COM410 Python Programming, Coleman University
# Ref 1: The Quick Python Book, 2nd Ed, Manning
# Ref 2: Learning Python, 5th Ed, O'Reilly

import sys         # Import the operating system module
import os          # Import the operating system module
import os.path     # Import the operating system path modullessonse
import datetime as dt
import re          # Regular Expressions module
import traceback   # Debugging errors during runtime
import urllib      # To download a file to a local directory
import subprocess  # To call other python script
import re

from DictionaryHelper import DisplayNumber

separator = '-' * 50


def menu(option):
    while option != 'Q':  # Q - Quit, 2nd - loop while the option is not this flag
        os.system("cls")  # Clears the screen
        print ""
        print "                Python-Lessons MENU"
        print "                -------------------\n"
        print "        1a - The Python programming language"
        print "        1b - "
        print "        1c - "
        print "        2a - "
        print "        2b - "
        print "        2c - "
        print "        3a - "
        print "        3b - "
        print "        3c - "
        print "        4a - "
        print "        4b - "
        print "        4c - "
        print "         Q - Quit"
        print ""
        # M - Whenever (M) is entered, the screen should clear and redraw the menu option.
        prompt = "        OPTION: " + option + "\b\b"  # Backspace to accept the user edit
        choice = raw_input(prompt)  # input() named raw_input() in 2.X [Ref 2. pg 1146]
        if choice == '':
            choice = option
        if choice is not None:
            option = choice.lower()
            print ""
            if option == 'q':
                break  # q - Quit, 1st - break out of the if block
            elif option == '1a':
                option_1a()
            elif option == '1b':
                option_1b()
            elif option == '1c':
                option_1c()
            elif option == '2a':
                option_2a()
            elif option == '2b':
                option_2b()
            elif option == '2c':
                option_2c()
            elif option == '3a':
                option_3a()
            elif option == '3b':
                option_3b()
            elif option == '3c':
                option_3c()
            elif option == '4a':
                option_4a()
            elif option == '4b':
                option_4b()
            elif option == '4c':
                option_4c()
            else:
                option = ' '


def option_1a():
    # Introduction to the Python programming language
    # a print statement can print multiple-lines within three double-quote marks  
    print """        1a - The Python programming language\n"
            Are you writing/running Python scripts on Windows or Unix?\n 
            Which version of Python (on Win32)? 2.7 or 3.4 \n, 
            Write program code with something more than a plain text-editor...
            On Windows, use 'Sublime Text 2' (Outstanding support for regular expressions)
               or other free IDEs: Eclipse, PyScripter, PyCharm (JetBrains)
               or MS Visual Studio Studio Plug-in= Iron Python.\n
            The Python IDLE tool is just used for quick checks of syntax compilation
            Python code is tokenized, lexed/parsed, compiled, and run.
            The code isn't checked at compile-time, it’s checked at run-time.
            It has dynamically-typed variables and infers the data type.\n
            Proper indentation is critically important for program execution
               and curly braces {} are not used for blocking-together code.\n
            Strings are unusual because there is no char. They are made with
            single-quotes, double-quotes, or triple double-quotes. And they are immutable.
            Strings can be formatted and is demonstrated in the next lesson...\n 
            """
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        print "        " + os.getcwd()  # Ref 1. pg 150
        raw_input("        Press the Enter key to continue")


def option_1b():
    # 
    # 
    print "        1b - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_1c():
    # 
    # 
    print "        1c - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_2a():
    # 
    # 
    print "        2a - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_2b():
    # 
    # 
    print "        2b - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_2c():
    # 
    # 
    print "        2c - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_3a():
    # 
    # 
    print "        3a - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':

        communities = {
            '92109': 'Pacific Beach',
            '92108': 'Mission Valley',
            '91941': 'La Mesa',
            '92126': 'Mira Mesa',
            '92110': 'Mission Valley',
            '92101': 'Downtown'}

        print 'The number of items in my dictionary : {0}'.format(len(communities))
        print separator

        for key, value in communities.items:
            print '[{0}] => {1}'.format(key, value)

        if communities.in_key('92154'):
            print 'Mission Valley is in the dictionary.'
        else:
            print 'The key is not found.'

        print separator
        current_key = '92110'
        if current_key in communities:
            print '{0} is in the dictionary'.format(current_key)
        else:
            print '{0} is not in the dictionary'.format(current_key)

        # Before you delete a key, first lookup the key to see if it exist.
        # del communities['92110']

        communities.setdefault('00000', '')
        print type(communities.keys())
        print communities.keys()
        print communities.values()

        for key, value in communities.items:
            print '[{0}] => {1}'.format(key, value)

        contents = {'eggs': 2, 'cheese': 5, 'grapes': 2, 'jello': 5}

        # It's never a good idea to use an exception to control your logic, like this!
        try:

            if contents['avocado'] > 0:
                print 'Let\'s make an avocado omellete.'
        except KeyError:
            print 'The key does not exists'
        except TypeError:
            pass

        return_results, the_keys = return_keys(some_dictionary)
        print the_keys

        print separator
        for eachItem in simple_generator_function():
            print eachItem
        print separator
        our_generator = simple_generator_function()
        print next(our_generator)
        print next(our_generator)  # a sequence, not an array

        raw_input("        Press the Enter key to continue")


def return_keys(a_dictionary):
    if isinstance(a_dictionary, dict):
        return True, a_dictionary.keys()
    return False, []


def do_something_silly(arg1):
    param1 = arg1
    param2 = 5 * 5

    return param1  # Python allows us to keep our place


def simple_generator_function():
    yield 1
    yield 2
    yield 3


def square(number):
    return number * number


def cube(number):
    return number * number * number


def display_number(number, radix=10, whatever='whatever'):
    if radix not in conversion.keys():  # Dictionary
        return 'Error'
    conversion = {
        2:	str(bin(number)),
        8:	str(oct(number)),
        10:	str(number),
        16:	format(number, '02x')
    }
    if whatever == 'whatever':
        whatever = 'Not used'
    else:
        whatever = 'Used'
    return conversion[radix], whatever


def display_number_old_too(number, radix=10):
    if radix not in conversion.keys():  # Dictionary
        return 'Error'
    conversion = {
        2:	str(bin(number)),
        8:	str(oct(number)),
        10:	str(number),
        16:	format(number, '02x')
        }
    return conversion[radix]


def display_number_old(number, radix=10):
    formatted_results = ''
    if radix not in valid_radices:
        return 'Error'

    conversion = {
        2:	str(bin(number)),
        8:	str(oct(number)),
        10:	str(number),
        16:	format(number, '02x')
        }
    if radix == 16:
        formatted_results = format(number, '02x')
    if radix == 10:
        formatted_results = str(number)
    if radix == 8:
        formatted_results = str(oct(number))
    if radix == 2:
        formatted_results = str(bin(number))
        # formatted_results = str(bin(number)[2:]

    return formatted_results


def option_3b():
    # 
    # 
    print "        3b - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        print separator
        print square(10)
        print cube(10)
        conversion = {}
        # print display_number_old(255, 16)
        print display_number_old_too(255, 16)
        results, what_is_whatever = display_number(whatever='Who are you', number=55)
        print 'Results is: {0} and whatever is: {1}'.format(results, what_is_whatever)


def option_3c():
    # 
    # 
    print "        3c - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def option_4a():
    # 
    # 
    print "        4a - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


    # You can comment-out code with an if block...
    if printStuff:
        
        tuple1 = ('one', 'two', 'three', 4, 1997, 2000);
        tuple2 = (1, 2, 3, 4, 5);
        tuple3 = "a", "b", "A", "Z";

        emptyTuple = ();

        singleValueTuple = (2, )

        tuple1[0] = 'five'

        print tuple1[0]

        # you can use the slice notation
        print tuple1[0:3]

        # The results will be a tuple of a tuple.
        print type(tuple1[0:3])

        first = (33, 44, 55)
        second = (66,)
        third = first + second
        print third   # results (33, 44, 55, 66)
        
        # You can't change a tuple but you can create a copy of a tuple.

        brandNewTuple = (10, 20, 30)
        print len(brandNewTuple)
        print (5, 9, 4) + (15, 19, 14)

        print (5, ) * 4    # duplicate instances of a tuple.

        if 20 in brandNewTuple:
            print 'The number is in brandNewTuple'

        for eachTupleItem in brandNewTuple:
            print eachTupleItem  * 2

        # The two functions of data type Tuple is the 'min' and 'max'
        print min(brandNewTuple)
        print max(brandNewTuple)
        print tuple(range(5, 15)) # using tuple to create a new tuple

        # Tuples are faster than using a List. It has a smaller big O.
        # Tuples are also safer because a user cannot change the data (they could change data in a list)

    # A tuple can convert a list into a tuple
    # 
    print id(b)

    print a.__sizeof__()
    print b.__sizeof__()

    a = tuple(range(1000))
    b = list(range(1000))

    print id(a)
    b = [1, 2]    # I'm changing the list now becaus eit is immutable
    b[0] = 3

    a = (1, 2)
    a[0] = 3   # results an error because we're trying to change the value of a tuple.

    # Python has the id function
    b.append(5)
    print b
    # result 8024, 9088

    sweet
    sweeeeet
    ^swe{2,4}t  # five e's will not match
    swewet  # matches

# Python uses curly braces for tuples
# they are immutable -  cannot modify the contents of aa tuple


def option_4b():
    # 
    # 
    print "        4b - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")

    # Regular expression
        {
#             string input = "5d";
#             string pattern = @"^\d+$";
#             string decimalPattern = @"^\d+\.\d+$";
#  
#             Regex re = new Regex(pattern, RegexOptions.Compiled);
#             Console.WriteLine(regex.IsMatch(input));
#         }
#         public bool ISValidNumber(string number, string pattern)
#         {
#             Regex regex = new Regex(pattern, RegexOptions.Compiled);
#             return regex.IsMatch(InputLanguage));
#         }


def IsValidNumber(number, pattern):
    # match only works with the beginning of the string
    # search finds matches throughout the string

    if len(pattern) == 0:
        return True

    isMatch = re.search("^\d+\.\d+$")  # isMatch is now an object
    # There are four types of function parameters
    if isMatch is None
        return True
    return true

    print IsValidNumber(59.999, "^\d+\.\d+$")


def option_4c():
    # 
    # 
    print "        4c - "
    print "             Press the Enter key to continue.."
    prompt = "             (or M for the main menu):  "
    user_input = raw_input(prompt)
    if user_input.upper() != 'm':
        raw_input("        Press the Enter key to continue")


def main():
    option = '1a'  # Default menu option '1a'
    menu(option)


try:    # Debugging with Outer try Statement replaces Python's Top-Level Exception Handling [Ref 2. pg 1149]
    main()
except EOFError, e:	 # raw_input() raises a built-in EOFError Exception Signal (not an error) [Ref 2. pg 1146]
    assert e
except:
    print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])    # Display all exceptions without program termination
    traceback.print_exc()										# Display the call stack [Ref 1. pg 1150]
    raw_input("        Press the Enter key to exit")
