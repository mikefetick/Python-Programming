from DictionaryHelper import *

results, value = DisplayNumber(3, 8)
print 'The number is: {0} and whatever is: {1}'.format(results, value)

someDictionary = {
			'92109':'Pacific Beach', 
			'92108':'Mission Valley', 
			'91941':'La Mesa', 
			'92126':'Mira Mesa', 
			'92110':'Mission Valley', 
			'92101':'Downtown'}  

returnResults, theKeys = returnKeys(someDictionary)
print theKeys

