#!/user/bin/python 	# On a Unix machine, this is where Python is installed
# -*- coding: iso-8859-15 -*-
# 1/8/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Ref 1: The Quick Python Book, 2nd Ed, Manning
# Ref 2: Learning Python, 5th Ed, O'Reilly

import sys, os 		# Import the operating system module
import os.path		# Import the operating system path module
import datetime as dt
import re 			# Regular Expressions module
import traceback	# Debugging errors during runtime
import urllib		# To download a file to a local directory
import subprocess	# To call other python script

def menu(option):
	while option != 'Q':	# Q - Quit, 2nd - loop while the option is not this flag
		os.system("cls")	# Clears the screen
 		print ""
		print "                MENU"   # The user interface (menu) is a specification
		print "                ----"   # Any changes will be in agreement with the client
		print ""
		print "        V - Print every third character in an expression"
		print "        R - Read an input file and count the number of words."
		print "        H - Read an HTML url and save the file locally"
		print "        C - Print the current directory location of where "
		print "            the script is executing"
		print "        F - Read an input file, do calculations, and format data"
		print "        D - Read an HTML url and count the tags"
		print ""        
		print "        A - Given a date, count the number of days"
		print "        P - Given an input string proper case each first letter"
		print "        Q - Quit"
		print ""
		# M - Whenever (M) is entered, the screen should clear and redraw the main menu
		prompt = "        OPTION: " + option + "\b"		# Backspace to accept the user edit
		choice = raw_input(prompt)		# input() named raw_input() in 2.X [Ref 2. pg 1146]
		if choice == '': choice = option
		if choice != None:
			option = choice.upper()
			print ""
			if option == 'V':	option_V()
			elif option == 'R': option_R()
			elif option == 'H': option_H()
			elif option == 'C': option_C()
			elif option == 'F': option_F()
			elif option == 'D': option_D()
			elif option == 'A': option_A()
			elif option == 'P': option_P()
			elif option == 'Q': break	# Q - Quit, 1st - break out of the if block
			else: option = ' '

def option_V():
	print "        V - Print every third character in an expression"
	print "            Enter a string at least ten characters long.."
	userInput_1 = ''
	if len(userInput_1) < 10: 	# V - The input string must be at least ten characters long.
		prompt = "            (or M for the main menu):  "
		userInput_1 = raw_input(prompt)
		if userInput_1.upper() != 'M': 	
			if len(userInput_1) < 10: 
				raw_input("        (Error: Less than ten characters long)")
			else: 
				i = 2			# Ref 2. pg 404
				pattern = '        '
				while i < len(userInput_1):
					pattern = pattern + userInput_1[i] + ' '
					i = i + 3
				print pattern		
				raw_input("        Press the Enter key to continue")

def option_R():
	print "        R - Read an input file and count the number of words"
	print "            Enter a filename.. or press the Enter Key to accept this one.."
	prompt = "            (or M for the main menu):  .\\us-constitution.txt" + ("\b")*21
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
								# R - Count the number of words, but do not include punctuation on either 
								#       end of the word.  Contractions are valid words.
		if userInput_1 == "": userInput_1 = '.\us-constitution.txt'
		inputFile = userInput_1
		if os.path.isfile(inputFile) and os.access(inputFile, os.R_OK):

			try:
				fileObject = open(inputFile, 'r')
				wordCount = 0
				for line in fileObject:
					for l in line.split(' '):	# this way handles excessive whitespace
						if l != "": wordCount = wordCount + 1
				# format for a comma separator	
				print "        The file's word count is:  " + '{:,}'.format(wordCount) + " words!"   
				# Ref: https://answers.yahoo.com/question/index?qid=20061011061230AAEU4xF			
				# The US Constitution has 7,369 words 
			except Exception, e:
				print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
				traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
				raw_input("        Press the Enter key to continue")

			finally:
				fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
		else:
		    print "        (Error: Either file is missing or is not readable)"
		raw_input("        Press the Enter key to continue")

def option_H():
	print "        H - Read an HTML url and save the file and directories locally"
	print "            Note: This works on my notebook (Win 8.1)"
	print "                  but not on my desktop PC (Win 7)!"
	print "            Enter an HTML url.. or press the Enter Key to accept this one.."
	prompt = "            (or M for menu):  http://vsbabu.org/webdev/pydev/htmlslurp.html" + ("\b")*45  # backspaces
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
		if userInput_1 == "": userInput_1 = 'http://vsbabu.org/webdev/pydev/htmlslurp.html'
		try:
			fileObject = open('URLFILE.txt', 'w')
			fileObject.write(userInput_1)
		except Exception, e:
			print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
			traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
			raw_input("        Press the Enter key to continue")
		finally:
			fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]

		# H - The file should be saved in the same directory where the script is executing
		# To download a file from a url to a local directory
		subprocess.call("slurp.py -i URLFILE.txt", shell=True)	
		raw_input("        Press the Enter key to continue")

def option_C():
	print "        C - Print the current directory location of where the script is"
	print "            Press the Enter key to continue.."
	prompt = "            (or M for the main menu):  "
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
		print "        " + os.getcwd()	# Ref 1. pg 150
		raw_input("        Press the Enter key to continue")

def option_F():
	print "        F - Read an input file, do calculations, and format data"
	print "            Enter a filename.. or press the Enter Key to accept this one.."
	prompt = "            (or M for the main menu):  .\\payroll.csv" + ("\b")*13
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
		# F - The file will be a CSV file and you will need to format the data into a report.  
		if userInput_1 == "": userInput_1 = '.\payroll.csv'
		inputFile = userInput_1
		if os.path.isfile(inputFile) and os.access(inputFile, os.R_OK):
			try:
				fileObject = open(inputFile, 'r')
				# I'll cover this in class next week on 01-13-2015.
				# 14.55,24,1st * 2nd,FICO,EXEMPTIONS, GROSS PAY, NET PAY
				# Joe Smith, 14.55, 24.00, 37.51, 3
				if fileObject:
					# Ref: http://stackoverflow.com/questions/1402048/how-do-i-right-align-numeric-data-in-python
					print '\n        {0:16}{1:>7}{2:>8}{3:>8}{4:>9}{5:>10}{6:>10}'.format(
						'EMPLOYEE','PAYRATE','WORKED','FICO','EXEMPT','GROSS','NETPAY')
					print '        {0:16}{1:>7}{2:>8}{3:>9}{4:>8}{5:>10}{6:>11}'.format(
						'--------','-------','------','-------','-------','---------','---------')
				for line in fileObject:
					# Initialize all variables, name is validation flag
					name = 'INVALID'
					hourlyRate = hourlyRate = hoursWorked = thierFICO = exemptions = grossPay = netPay = '*****'
					fieldCount = 0
					# Necessary to ensure there is data	
					for data in line.split(','):
						# Necessary to skip header record if it exists.
						if data != "": 
						# if any([data != "EmployeeID" and 
								# data != "FirstName" and 
								# data != "LastName" and 
								# data != "PayRate" and 
								# data != "HoursWorked" and 
								# data != "Fico" and
								# data != "Exemptions"]): 
							data = data.strip()
							fieldCount = fieldCount + 1
							# Validate data in each field to arbitrary business rules
							if fieldCount == 1: name = (data if len(data) < 15 else '-ERROR-')
							# Ref: http://stackoverflow.com/questions/1549801/differences-between-isinstance-and-type-in-python 
							elif fieldCount == 2: 
								data = float(data)
								if isInt(data) or isFloat(data):
									hourlyRate = data
									if (data > 35) : hourlyRate = ' -OVER-'    # Maximum wage paid by this company
									elif (data < 9) : hourlyRate = ' -BELOW-'  # Below CA minimal wage - $9 per hour
								else: hourlyRate = ' -ERROR-'  # Catch non-ordinal values
							elif fieldCount == 3: 
								data = float(data)
								if isInt(data) or isFloat(data):
									hoursWorked = data
									if (hoursWorked > 40) : hoursWorked = ' -OVER-'    # Maximum - Overtime is not offered
									elif (hoursWorked < 0) : hoursWorked = ' -BELOW-'  # Only pay for hours worked
								else : hoursWorked = ' -ERROR-'  # Catch non-ordinal values
								if (hoursWorked != ' -OVER-' 
									and hoursWorked != ' -BELOW-' 
									and hoursWorked != ' -ERROR-' 
									and hourlyRate != ' -OVER-' 
									and hourlyRate != ' -BELOW-' 
									and hourlyRate != ' -ERROR-') : grossPay = float(hourlyRate * hoursWorked)  # Compute with valid operands
								# Computed result, now format operands to currency
								if (hourlyRate != ' -OVER-' 
									and hourlyRate != ' -BELOW-' 
									and hourlyRate != ' -ERROR-') : hourlyRate = '$ %.2f' % (hourlyRate)
								if (hoursWorked != ' -OVER-' 
									and hoursWorked != ' -BELOW-' 
									and hoursWorked != ' -ERROR-') : hoursWorked = '%.2f' % (hoursWorked)
								else: grossPay = ' -ERROR-'
							elif fieldCount == 4: 
								data = float(data)
								if isInt(data) or isFloat(data):
									thierFICO = data
									if (thierFICO < 0) : thierFICO = ' -BELOW-'  # Only pay for hours worked
								else: thierFICO = ' -ERROR-'  # Catch non-ordinal values
							elif fieldCount == 5:
								data = int(data)
								# Ref: http://stackoverflow.com/questions/4541155
								if isInt(data) or isFloat(data):
									exemptions = data
									if isFloat(data) : exemptions = int(round(exemptions))
									if (exemptions < 0) : exemptions = ' -BELOW-'  # Only pay for hours worked
									# Ref: http://stackoverflow.com/questions/181530/
									exemptions = (exemptions 
										if any([exemptions == 0, 
												exemptions == 1, 
												exemptions == 2, 
												exemptions == 3, 
												exemptions == 4]) else ' -ERROR-')
									# Exemptions can be 0 to 4
									if exemptions == 0:	
										exemptions = '    ' + str(exemptions) + '   '
										deductionRate = .25 
									elif exemptions == 1: 
										exemptions = '    ' + str(exemptions) + '   '
										exemptions = ' -ERROR-'
										deductionRate = .20
									elif exemptions == 2: 
										exemptions = '    ' + str(exemptions) + '   '
										deductionRate = .15
									elif exemptions == 3: 
										exemptions = '    ' + str(exemptions) + '   '
										deductionRate = .10
									elif exemptions == 4: 
										exemptions = '    ' + str(exemptions) + '   '
										deductionRate = .05
									else: 
										exemptions = ' -ERROR-'
										deductionRate = 0   # Excessive exemptions is error 
									otherDeductions = 0   # Future usage
								else: exemptions = ' -ERROR-'  # Catch non-ordinal values
								if (grossPay != ' -ERROR-' and thierFICO != ' -ERROR-'):   
									netPay = grossPay - thierFICO
									thierFICO = '$ %.2f' % (thierFICO)
									# The remaining data has valid context so format to currency
									if exemptions != ' -ERROR-':   
										deductions = (grossPay * deductionRate) + otherDeductions
										netPay = netPay - deductions
									netPay = '$ %.2f' % (netPay)
									grossPay = '$ %.2f' % (grossPay)
								else:
									# For any data that has valid context, format to currency
									#if (hourlyRate != ' -OVER-' and hourlyRate != '-----'): hourlyRate = '$ %.2f' % (hourlyRate)
									#if (hoursWorked != ' -OVER-' and hoursWorked != '-----'): hoursWorked = '$ %.2f' % (hoursWorked)
									#if (thierFICO != ' -OVER-' and thierFICO != '-----'): thierFICO = '$ %.2f' % (thierFICO)
									netPay = ' -ERROR-'
						else: print "        ERROR: Encountered line of no data"
					if name != 'INVALID': 
						col_1 = name
						col_2 = hourlyRate
						col_3 = hoursWorked
						col_4 = thierFICO
						col_5 = exemptions
						col_6 = grossPay
						col_7 = netPay
						# Ref: https://docs.python.org/2/tutorial/inputoutput.html
						print '        {0:16}{1:>7}{2:>8}{3:>9}{4:>8}{5:>10}{6:>11}'.format(
							col_1, col_2, col_3, col_4, col_5, col_6, col_7)
				# After all data is printed
				print ""

			except Exception, e:
				print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
				traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
				raw_input("        Press the Enter key to continue")
			finally:
				fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
		else:
		    print "        (Error: Either file is missing or is not readable)"
		raw_input("        Press the Enter key to continue")

def option_D():
	print "        D - Read an HTML url and count the tags"
	print "            Enter an HTML url.. or press the Enter Key to accept this one.."
	prompt = "            (or M for menu):  https://www.yahoo.com/" + ("\b")*22   # backspaces
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
		if userInput_1 == "": userInput_1 = 'https://www.yahoo.com/'
		try:
			fileObject = urllib.urlopen(userInput_1)	# urllib self.closes
			dataStr = fileObject.read()
		except Exception, e:
			print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
			traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
			raw_input("        Press the Enter key to continue")
		else:
			# D - Include both opening and closing tags, tags that contain multiple attributes and single div tags.
			# Ref: https://www.daniweb.com/software-development/python/threads/197400/python-count-html-tags
			ultimate_regexp = "(?i)<\/?\w+((\s+\w+(\s*=\s*(?:\".*?\"|'.*?'|[^'\">\s]+))?)+\s*|\s*)\/?>"
			etcount = 0
			otcount = 0
			for match in re.finditer(ultimate_regexp, dataStr):
				if repr(match.group()).startswith("'</"):
					etcount += 1
				else:
					otcount += 1
			print "        Count opening HTML tags:   " + str(otcount)
			print "        Count closing HTML tags:   " + str(etcount)

		finally:
			fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
			raw_input("        Press the Enter key to continue")

def option_A():
	# A - Count the number of days that has elapsed until the current date
	# Ref: https://www.daniweb.com/software-development/python/code/216974/days-between-2-dates
	date1 = dt.date.today()
	date1Str = str(date1)
	y1, m1, d1 = (str(s) for s in date1Str.split('-'))
	date1Str = m1 + '/' + d1 + '/' + y1					# US format month/day/year
	print "        A - Given a date, count the number of days elapsed until today"
	print "            Enter date, before today:  " + date1Str
	prompt = "            (or M for the main menu):  "
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
		# Validate date format. Ref: http://www.regexlib.com/REDetails.aspx?regexp_id=60 (Limits to after 1989)
		# regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/(([1]{1}[9]{1}[9]{1}\d{1})|([2-9]{1}\d{3}))$") 
		regexp = re.compile(r"^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/\d{4}$") 
		if regexp.match(userInput_1):
			dateStr2 = userInput_1
			m2, d2, y2 = (int(x) for x in dateStr2.split('/'))
			date2 = dt.date(y2, m2, d2)
			# 
			if date1 > date2:
				dateDiff = date1 - date2

				#dateDiffStr = str(dateDiff).strip(', 0:00:00')	# Strip the time - (unused, I want commas)
				dayStr = (' days' if dateDiff.days > 1 else ' day')		# ternary assignment
				dateDiffStr = '{:,}'.format(dateDiff.days) + dayStr		# format for a comma separator

				print '              Difference in days:  %s' % dateDiffStr
				raw_input("        Press the Enter key to continue")
			else:
				print "        (Error: Please enter a date prior to today's date)"
				raw_input("        Press the Enter key to continue")
		else:
			print "        (Error: Not valid format:  MM/DD/YYYY)"
			raw_input("        Press the Enter key to continue")

def option_P():
	print "        P - Given an input string proper case each first letter"
	print "            Enter a string of at least two words.."
	prompt = "            (or M for the main menu):  "
	userInput_1 = raw_input(prompt)
	if userInput_1.upper() != 'M': 
								# P - You are not allowed to use the title() or captialize() functions.  Check 
								#       the length of your input string.  It should be at least two tokens.
		if len(userInput_1.split()) > 1:
			properCaseStr = ''
			for s in userInput_1.split(' '):	# this way handles excessive whitespace
				if s != "": properCaseStr = properCaseStr + (' '.join([s[0].upper() + s[1:]])) + " "
			#properCaseStr = ' '.join([s[0].upper() + s[1:] for s in userInput_1.split(' ')])

			print "        With proper case applied:  " + properCaseStr 
		else:
			print "        (Error: Please enter more words)" 
		raw_input("        Press the Enter key to continue")

def isInt(number): 
	#return int(number) == number
	return isinstance(number, int)

def isFloat(number): 
	#return float(number) == number 
	return isinstance(number, float)

def main():
	option = 'V'	# Default menu option 'V'
	menu(option)

try:	# Debugging with Outer try Statement replaces Phython's Top-Level Exception Handling [Ref 2. pg 1149]
	main()
except EOFError, e:	# raw_input() raises a built-in EOFError Exception Signal (not an error) [Ref 2. pg 1146]
	assert e
except:
	print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])	# Display all exceptions without program termination
	traceback.print_exc()										# Display the call stack [Ref 1. pg 1150]
	raw_input("        Press the Enter key to exit")
