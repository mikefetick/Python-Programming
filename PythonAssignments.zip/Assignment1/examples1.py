#!/user/bin/python 	# On a Unix machine, this is where Python is installed
import os 			# Import the operating system module
os.system(“cls”)	# Clears the screen

exp = 'This is a test, today is Tuesday'

exp[0]		# 'T'
len(exp)	# 32
exp[len(exp) - 1]	# 'y'
exp[-1]		# 'y'
exp[0:4]	# 'This'
exp[-6:-2]	# 'uesd'
exp[:3]		# 'Thi'
exp[-3]		# 'd'
exp[-3:]	# 'day'
exp[-3:4]	# ''
piece = exp[-3:]
print (piece)	# day
print exp[:] 	# This is a test, today is Tuesday
print (exp[:])	# This is a test, today is Tuesday
test = 1
number = 11
test = number > 10
test == 11 		# True
test == True 	# True
test == 0 		# False
test2 = number < 10
test == False 	# False
print (test2) 	# False
test2 == 0 		# True

data = "This is a test"
results = "x" in data
isValid = 
mySlice == 'Thi'
if isValid:
print 'The pattern exists':
isValid = True
elseIf mySlice == ‘Crazy’
	doSomethingElse
else:
print 'The pattern does not exist':
endIf;

