#!/user/bin/python 	# On a Unix machine, this is where Python is installed
# -*- coding: iso-8859-15 -*-
# 2/17/2015 Michael Fetick, 84270, COM410 Python Programming, Coleman University
# Assignment 2 - Regular Expressions and Dictionaries
# Ref 1: The Quick Python Book, 2nd Ed, Manning
# Ref 2: Learning Python, 5th Ed, O'Reilly


import sys, os 		# Import the operating system module
import os.path		# Import the operating system path module
import re 			# Regular Expressions module
import traceback	# Debugging errors during runtime
import string
import collections


separator = "    " + '-' * 59
def menu():
	os.system("cls")	# Clears the screen
	print ""
	print "                     COM410 Python Programming"
	print "        Assignment 2 - Regular Expressions and Dictionaries"
	print separator
	print "        Subroutines:"
	print "            menu()                      dict_lookup_output()"
	print "            build_dict()                compute_counts()"
	print "            read_file_io()              write_file_io()"
	print "            filter_dup_keys()           deliverables()"
	print "            filter_by_re()"
	print "                                    Q - Quit "
	print separator


def choose():
	print "\n            --- continue by pressing the Enter key ---"
	print "                   or enter 'q' to quit:",
	prompt = " \b"
	choice = raw_input(prompt)
	if ( choice.lower() ) == 'q':	
		try:
			os._exit(1)
		except Exception:
			pass
	else: return


def program_menu():
	menu()
	print "            menu()"	
	print """
        Create a menu based program for this assignment.
        Subroutines listed above are called to do it. \n"""
	print "\n"*3
	choose()


def build_dict(acData):
	menu()
	print "            build_dict()"	
	print """
	Your task is to build a dictionary from the first file 
	where the area code is the key to the dictionary. 
	The first file may or may not contain duplicate keys. \n"""
	# http://stackoverflow.com/questions/1024847/add-to-a-dictionary-in-python
	print '        (Ref: http://stackoverflow.com/'
	print '              questions/1024847/add-to-a-dictionary-in-python)'
	print "\n            a. #### Making a dictionary ####"
	print "               acData = {}"
	print "               # OR #"
	print "               acData = dict() \n"
	print "            b. #### Initially adding values ####"
	print "               (We won't be doing this here.)"
	print "               data = {'a':1,'b':2,'c':3}"
	print "               # OR #"
	print "               data = dict(a=1, b=2, c=3) \n"
	print "        acData = dict()"
	acData = dict()
	print "        print acData"
	print "        ", acData
	choose()
	return acData


def read_file_io(acData):
	menu()
	print "            read_file_io()"	
	print """
	This assignment involves reading two text files. \n
	1.  The first file contains a series of area codes 
	    mapped to a region, named AreaCodes.txt file. \n"""
	inputFile = '.\AreaCodes.txt'
	data = 'INVALID'
	areacode = ''
	region = ''
	if os.path.isfile(inputFile) and os.access(inputFile, os.R_OK):
		try:
			fileObject = open(inputFile, 'r')
			if fileObject:
				print "            a. file: "+inputFile+" is open to read."	
				#dataStr = fileObject.read()
				regexpAreacode = re.compile("(\d{3})") 
				i = 0
				j = 0
				for line in fileObject:
					j += 1   # all lines
					matched = regexpAreacode.findall(line)
					if matched:
						areacode = matched[0]
						region = line.strip()
						region = region.lstrip(areacode)
						region = region.strip()
						# Update the dictionary here
						acData[areacode]=region
						i += 1   # matched lines
						# print '               '+str(i)+') '+str(areacode)+' - '+str(region)
						data = 'VALID'
				countRecordsOfAreacodeFile = j
				# This computed value is stored in the global variable: 
				global countStats
				countStats[0] = countRecordsOfAreacodeFile
				if data == 'VALID': 
					print "\n            b. valid data was found. \n"
				else:
					print "\n            b. valid data was not found. \n"
			print "            c. #### Inserting/Updating value #### "
			print "               # updates if areacode exists, else adds areacode "
			print "               acData[areacode]=region \n"
			print "        acData[areacode]=region \n"
			print "            d. all data from the file has been read. \n"	
			print '               countRecordsOfAreacodeFile: ',countStats[0]
			print ""

		except Exception, e:
			print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
			traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
			raw_input("        Press the Enter key to continue")
		finally:
			fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
			print "            e. file: "+inputFile+" is closed."
	else:
	    print "        (Error: Either file is missing or is not readable)"
	choose()
	print ""
	print acData
	#for k, v in acData:
	#	print k + " : " + v
	print "\n            f. The dictionary was built."
	choose()
	return acData


def filter_dup_keys(acData):
	menu()
	print "            filter_dup_keys()"	
	print """
	You are to filter out the duplicate keys on a first 
	come first serve basis. """

	value_occurrences_before = 0
	value_occurrences_after = 0
	value_occurrences_before = collections.Counter(acData.values())
	filtered_dict = {key: value for key, value in acData.items() if value_occurrences_before[value] == 1}
	value_occurrences_after = collections.Counter(filtered_dict.values())
	acData = filtered_dict
	countAreacodes = len(value_occurrences_after)
	# This computed value is stored in the instance variable: 
	countStats[1] = countAreacodes
	duplicateAreacodes = len(value_occurrences_before) - len(value_occurrences_after)

	print "          Before filtering: ", len(value_occurrences_before)
	print "         - After filtering: ", countAreacodes
	print "        ------------------------ "
	print "        Duplicates deleted:  ", duplicateAreacodes

	print '            countAreacodes: ',countStats[1]
	choose()
	return acData


def filter_by_re(acData):
	menu()
	print "            filter_by_re()"	
	print """
	2.  The second file contains a series of phone numbers,
	    named PhoneNumbers.txt file. \n
	Once you have successfully built the dictionary.  
	Read the second file of phone numbers and filter out the
	invalid phone numbers by employing regular expressions. 
	You should then have a valid list of phone numbers. \n"""
	inputFile = '.\PhoneNumbers.txt'
	telData = dict()
	data = 'INVALID'
	areacode = ''
	exchange = ''
	linenumber = ''
	phonenumber = ''
	if os.path.isfile(inputFile) and os.access(inputFile, os.R_OK):
		try:
			fileObject = open(inputFile, 'r')
			if fileObject:
				print "            a. file: "+inputFile+" is open to read."	
				regexpPhonenumber = re.compile("(\d{10})") 
				i = 0
				j = 0
				for line in fileObject:
					j += 1   # all lines
					matched = regexpPhonenumber.findall(line)
					if matched:
						areacode = str(matched)[2:5]
						exchange = str(matched)[5:8]
						linenumber = str(matched)[8:12]
						phonenumber = exchange+'-'+linenumber
						# Update the dictionary here
						telData[areacode]=phonenumber
						i += 1
						print '               '+str(i)+') ('+str(areacode)+') '+str(phonenumber)
						data = 'VALID'
				countRecordsOfPhonenumbersFile = j
				# This computed value is stored in the global variable: 
				global countStats
				countStats[2] = countRecordsOfPhonenumbersFile
				countPhoneNumbers = countRecordsOfPhonenumbersFile - i
				# This computed value is stored in the global variable: 
				countStats[3] = countPhoneNumbers
				if data == 'VALID': 
					print "\n            b. valid data was found. \n"
				else:
					print "\n            b. valid data was not found. \n"
			print "            c. #### Inserting/Updating value #### "
			print "               # updates if areacode exists, else adds areacode "
			print "               telData[areacode]=phonenumber \n"
			print "        telData[areacode]=phonenumber \n"
			print "            d. all data from the file has been read. \n"	
			print '               countRecordsOfPhonenumbersFile: ',countStats[2]
			print '               countPhoneNumbers: ',countStats[3]

		except Exception, e:
			print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
			traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
			raw_input("        Press the Enter key to continue")
		finally:
			fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
			print "            e. file: "+inputFile+" is closed."
	else:
	    print "        (Error: Either file is missing or is not readable)"
	choose()
	print ""
	print telData
	print "\n            f. The list of telephone numbers was built."
	choose()
	return telData


def dict_lookup_output(acData, telData):
	menu()
	print "            dict_lookup_output()"	
	print """
	Go through each set of phone numbers and extract the 
	first three digits and use those three digits to do a 
	dictionary lookup.  If the area code is in the 
	dictionary, then the output format (when saved to a 
	file) should look like:
	    (763) 555-3849 => Minneapolis, St. Paul
	    (213) 593-4972 => Los Angeles """

	value_occurrences_before = collections.Counter(telData.values())
	phonenumberRegionLookup = {}
	print "\n        Results: "
	leftHandSide = ''
	rightHandSide = ''
	for key in sorted(telData.keys()):
		leftHandSide = '(%s) %s' % (key, telData[key])
		print '             %s => ' % (leftHandSide),
		filtered_dict = {}
		if (key) in acData:
			filtered_dict = {key: value for key, value in acData.items()}
			rightHandSide = filtered_dict[key]
			print filtered_dict[key]
		else:
			print ""
			rightHandSide = ' '
		phonenumberRegionLookup [leftHandSide] = rightHandSide
	print phonenumberRegionLookup

	value_occurrences_after = collections.Counter(filtered_dict.values())
	countAreacodeLookup = sum(value_occurrences_after.values())
	# This computed value is stored in the global variable: 
	global countStats
	countStats[4] = countAreacodeLookup
	print '               countAreacodeLookup: ',countStats[4]
	choose()
	return 	phonenumberRegionLookup



def compute_counts():
	menu()
	print "            compute_counts()"	
	print """
	Your program should give me a total count of:
	1.  Valid Phone Numbers
	2.  Invalid Phone Numbers
	 """
	# These computed values are stored in the global variable: 
	global countStats
	#   countStats[0] = read_file_io(acData)::countRecordsOfAreacodeFile
	#   countStats[1] = filter_dup_keys(acData)::countAreacodes
	#   countStats[2] = filter_by_re(acData)::countRecordsOfPhonenumbersFile
	#   countStats[3] = filter_by_re(acData)::countPhoneNumbers
	#   countStats[4] = dict_lookup_output(acData, telData)::countAreacodeLookup
	validPhoneNumbers = countStats[3]                       #  17
	invalidPhoneNumbers = countStats[2] - countStats[3]     # 133
	invalidAreacodeRegions = countStats[0] - countStats[4]  # 394
	validAreacodeRegions = countStats[4]                    # 394
	print "        Results:"
	print "        1.  Valid Phone Numbers:      ", validPhoneNumbers
	print "        2.  Invalid Phone Numbers:    ", invalidPhoneNumbers
	print "        3.  Invalid area code region: ", invalidAreacodeRegions
	print "        4.  Valid area code region:   ", validAreacodeRegions

	print "\n        For Test:"
	print "        #   countStats[0] = read_file_io(acData)::countRecordsOfAreacodeFile         ", countStats[0]
	print "        #   countStats[1] = filter_dup_keys(acData)::countAreacodes                  ", countStats[1]
	print "        #   countStats[2] = filter_by_re(acData)::countRecordsOfPhonenumbersFile     ", countStats[2]
	print "        #   countStats[3] = filter_by_re(acData)::countPhoneNumbers                  ", countStats[3]
	print "        #   countStats[4] = dict_lookup_output(acData, telData)::countAreacodeLookup ", countStats[4]
	print "\n"*2
	choose()


def write_file_io(outputDict):
	menu()
	print "            write_file_io()"	
	print """
	When you save your output to a file, do not hard-code 
	the path.  The file should be saved relative to where 
	your script runs. """

	outputFile = '.\phonenumberLookup.txt'
	try:
		fileObject = open(outputFile, 'w')
		print "            a. file: "+outputFile+" is open to read."	
		with fileObject as f:
		    [f.write('{0},{1}\n'.format(key, value)) for key, value in outputDict.items()]
		print "            b. all data has been written to the file. \n"	
		os.system('type %s' % outputFile)	# Type the file to the scrren
		print "# Typed the file to the screen with this:"
		print "os.system('type %s' % outputFile)"
		print ""

	except Exception, e:
		print('Error', sys.exc_info()[0], sys.exc_info()[1])	# Display exceptions info
		traceback.print_exc()									# Display the call stack [Ref 1. pg 1150]
		raw_input("        Press the Enter key to continue")
	finally:
		fileObject.close()	# Always close the file to flush output buffers. [Ref 2. pg 1102]
		print "            c. file: "+outputFile+" is closed."
	choose()


def deliverables():
	menu()
	print "            deliverables()"	
	print """
	Submit your file as:  COM410-12345-02.zip.  It is not 
	necessary to send me the phone number or area code 
	files.  I will use my own. """
	print "\n"*3
	choose()


# Computed values are stored in this global variable: 
countStats = [0,0,0,0,0]

def main():
	if __name__ == "__main__":
		program_menu()
		acData = dict()
		telData = dict()
		acData = build_dict(acData)
		acData = read_file_io(acData)
		acData = filter_dup_keys(acData)
		telData = filter_by_re(acData)
		outputDict = dict_lookup_output(acData, telData)
		compute_counts()
		write_file_io(outputDict)
		deliverables()

try:	# Debugging with Outer try Statement replaces Phython's Top-Level Exception Handling [Ref 2. pg 1149]
	main()
except EOFError, e:	# raw_input() raises a built-in EOFError Exception Signal (not an error) [Ref 2. pg 1146]
	assert e
except:
	print('uncaught!', sys.exc_info()[0], sys.exc_info()[1])	# Display all exceptions without program termination
	traceback.print_exc()										# Display the call stack [Ref 1. pg 1150]
	raw_input("        Press the Enter key to exit")
