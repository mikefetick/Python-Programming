#!/user/bin/python 	# on a Unix machine or otherwise ignored by MS Windows

import pip

installed_packages = pip.get_installed_distributions()

installed_packages_data = sorted (
    ["%s == %s"%(i.key, i.version) for i in installed_packages]
)

print installed_packages_data

print type(installed_packages)

print isinstance(installed_packages, 'list')